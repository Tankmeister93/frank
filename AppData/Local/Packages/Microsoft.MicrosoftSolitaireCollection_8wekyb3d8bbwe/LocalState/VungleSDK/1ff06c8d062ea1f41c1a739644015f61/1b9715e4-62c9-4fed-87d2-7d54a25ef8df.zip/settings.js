var PiecSettings = PiecSettings || {};

PiecSettings.version = "-";

PiecSettings.autospin = {
    activateAfter: 7500,
}

//////// DEFAULT SETTINGS FOR SLOT GAMES ////////

PiecSettings.winlinePalette = [0xfdf9c6, 0xf3d868, 0xc98e43, 0xff8247, 0xfaed60, 0xeba22c]; //Colours used by the winlines
PiecSettings.fontColor = "#ffffff"; //Remove empty if you want to use the default golden gradient
PiecSettings.fontFamily = "Marion Bold"; //Make sure that this font is on the css and that there is a div that uses it. (preload-font div)
PiecSettings.BigWinFontFamily = "Marion Bold"; //Make sure that this font is on the css and that there is a div that uses it. (preload-font div)

// CTA BUTTON

PiecSettings.ctaText = {
    autolocalise: true,
    container: 'cta-custom-text',
    text: 'Play Now',
    // Adjust text position with anchor
    anchor: { x: 0.5, y: 0.5 },
    style: {
        fontWeight: "bold",
        fontFamily: PiecSettings.fontFamily,
                color: ['#e6e6e6'], // if there is no gradient, leave only one color in the array
        // stroke: '#016d03', // if there is no stroke, can delete it
        // strokeThickness: 10,
       // lineJoin: "round",
        // stroke: '#3a5208',
       //  strokeThickness: 3,
        fontCase: 'uppercase', // 'uppercase'
        shadow: {
            x: 2,
            y: 2,
            color: 'rgba(19,19,19,0.5)', 
            blur: 0
        },
    },
}
PiecSettings.CTAButtonBounceIn = 400;
PiecSettings.CTAButtonFadeIn = 400;


//////// SLOTS GAME SETTINGS ///////////////

PiecSettings.tooltip = { // If there is a "src" value, it will always pic the image.
    text: "SPIN TO\nWIN!",
    fontColor: "#ffffff", //Remove if you want to use the default golden gradient
    src: 'tooltip.png',
};

PiecSettings.reelLayout = [3,3,3]; // Heights of each of the reels in array form, where the first item is the height of the first reel, and so on.
PiecSettings.reelLayoutLandscape = [3,3,3,3,3,3]; // Heights of each of the reels in array form, where the first item is the height of the first reel, and so on.

PiecSettings.reels = [ // Tease on first spin, win on second, big win on third      // "B","C","E","H","J","L","P","R","S","W",

    [ // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "L","W","P","H","W","W","P","R","S","W", // 3
     "B","C","E","H","J","L","P","R","S","W",
     "J","R","E","H","W","W","P","R","S","W", // 2
     "S","W","P","H","W","W","P","R","S","W", // 2 fin
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "L","P","H","H","W","W","P","R","S","W", // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","L","P","C"
    ],
    [ // 2
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "B","W","P","L","P","R","S","W","B","C",//  3
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "B","E","P","L","P","R","S","W","B","C", // 2
     "S","W","P","L","P","R","S","W","B","C",//  2 fin
     "P","L","W","L","P","R","S","W","B","C", 
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C", 
     "C","S","L","L","P","R","S","W","B","C", // 1
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","C",
     "E","H","J","L","P","R","S","W","B","H"
     ],
    [ // 3
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "L","W","P","H","J","L","P","R","S","W", // 3
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "E","L","C","H","J","L","P","R","S","W", // 2
     "S","W","P","H","J","L","P","R","S","W", // 2 fin
     "H","L","W","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "S","P","S","H","J","L","P","R","S","W", // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","C","S","L"
     ],
    [ // 4
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","W","P","H","J","L","P","R","S","W", // 3
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "H","E","P","H","J","L","P","R","S","W", // 2
     "S","W","P","H","J","L","P","R","S","W", // 2 fin
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "H","L","P","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "L","S","H","H","J","L","P","R","S","W", // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","L","E","P"
     ],
    [
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","C","H","J","L","P","R","S","W",
     "C","W","P","H","J","L","P","R","S","W", // 3
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","E","L","H","J","L","P","R","S","W", // 2
     "S","W","P","H","J","L","P","R","S","W", // 2 fin
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","H","L","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "L","W","J","H","J","L","P","R","S","W", // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","P","C"
     ],
    [ // sixth
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","E","H","J","L","P","R","S","W",
     "C","C","C","H","J","L","P","R","S","W",
     "C","W","P","H","J","L","P","R","S","W", // 3
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","E","H","H","J","L","P","R","S","W", // 2
     "S","W","P","H","J","L","P","R","S","W", // 2 fin
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "C","H","L","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "W","L","P","H","J","L","P","R","S","W", // 1
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","S","W",
     "B","C","E","H","J","L","P","R","P","C"
     ],    // ["C","C","C","C","C","C","L","R","B","S","P","C","C","E","E","E","W","W","W","W","W","W","W","L","H","H","C","C","C","C","C","C","P","L","C","C","C"],
    // ["W","W","W","L","B","J","J","J","E","W","W","W","W","B","E","E","P","S","H","J","J","J","J","J","J","H","H","H","P","H","S","E","J","J","J","H","R","P"],
    // ["C","C","C","C","C","H","P","R","H","C","C","C","C","E","E","E","P","W","W","W","W","W","H","H","J","J","J","E","C","C","C","P","J","J","J","J","J","J","E","S","J"],
    // ["C","C","C","C","C","H","P","R","H","C","C","C","C","E","E","E","P","W","W","W","W","W","H","H","J","J","J","E","C","C","C","P","J","J","J","J","J","J","E","S","J"],
    // ["C","C","C","C","C","H","P","R","H","C","C","C","C","E","E","E","P","W","W","W","W","W","H","H","J","J","J","E","C","C","C","P","J","J","J","J","J","J","E","S","J"],
];
PiecSettings.reelsAnimation = {
    delayPerReel: [0,0,0,0,0,0],
};

/////// Win Counter settings
PiecSettings.winCounterInitialValue = 0;
PiecSettings.winCounterCommaSeparation = true; //One thousand will appear as 1,000 if this is true; 1000 if this is false

/////// Control symbol vertical spacing here
PiecSettings.symbolHeight = 150; // 150

/////// FINAL OVERLAY SCREEN SETTINGS ///////
/*
PiecSettings.finalOverlay = {
    color: 0x000000,
    alpha: 0.5,
    delay: 3000,
};
*/

/////// SLOTS SPINS SETTINGS ////////

PiecSettings.spins = [
    { // Spin 1
        stopPositions: [270,260,250,240,230,230], //Stop positions for Spin 1, for each of reels 1, 2 and so on
        winlines: [ // Highlighted winlines
        //    [2,1,0,1,2], // Specifies the symbol index that needs to be highlighted per reel. 0,0,0 is the first row
        //    [1,1,1,1,1], // 1,1,1 is the second row
        ],
        // respinFeature: {
        //     newStopPositions: [12,11,12],
        // },
        winCounter: 250000,
    },
    { // Spin 2
        stopPositions: [270 - 30, 260 - 40, 250 - 50, 240 - 60, 230 - 70, 230 - 70], //Stop positions for Spin 1, for each of reels 1, 2 and so on
        winlines: [
            [0,0,0,0,0,0],
            [1,1,1,1,1,1],
            [2,2,2,2,2,2]
        ],
        /*
        winlines: [
            [2,1,0,1,1],
        ],
        */
        // respinFeature: {
        //     newStopPositions: [13,13,12],
        // },
        // symbolPatternFeature: {
        //     symbol: 'W',
        //     pattern:  [
        //         [1],
        //         [],
        //         [1]
        //     ],
        // },
        winCounter: 1200000,
    }/*
    { // Spin 3
        stopPositions: [270 - 30 - 30, 260 - 40 - 40, 250 - 50 - 50, 240 - 60 - 60, 230 - 70 - 70], //Stop positions for Spin 1, for each of reels 1, 2 and so on
        winlines: [
            [1,1,1,1,1],
            [2,2,2,2,2],
        ],
        // respinFeature: {
        //    newStopPositions: [0,0,0],
        //},
        winCounter: 5000000,
        // winMessage: {
        //     src: "hugewin---.png",
        //     animation: 'zoom-and-bounce-in',
        //     duration: 1000,
        //     delay: 4700,
        // }
    }
    */
];

PiecSettings.ctaButtonText = 'Download';

var defaultLang = "en";
PiecSettings.translations = {
    'Download': {
        en: "Download",
        ja: "ダウンロード",
        ko: "다운로드",
        zh: "下载",
        de: "Download",
        fr: "Télécharger",
        it: "Scarica",
        es: "Descargar",
        pt: "Baixar",
        ca: "Descarregar",
        ru: "Скачать",
        tr: "Indir",
        nl: "Download",
        sv: "Ladda ner",
        id: "Download",
        ro: "Descărcare",
        ar: "تحميل",
        uk: "скачати",
        no: "Nedlasting",
        nb: "Nedlasting",
        nn: "Nedlasting",
        he: "הורד",
        ms: "ഡൗൺലോഡ്",
        th: "ดาวน์โหลด",
        pl: "Pobierz",
        be: "спампаваць",
        el: "κατεβάστε",
        bg: "изтегляне",
        da: "Hent",
        sr: "довнлоад",
        kk: "жүктеу",
        vi: "Tải về",
        hr: "zbirka",
        km: "ទាញយក",
        sq: "Shkarko",
        sl: "prenesi",
        lt: "parsisiųsti",
        az: "yükləyin",
        zu: "ukulanda",
        ga: "íoslódáil",
        is: "sækja",
        hu: "Letöltés",
        lv: "lejupielādēt",
        ka: "ჩამოტვირთვა",
        mt: "niżżel",
        et: "lae alla",
        ne: "डाउनलोड",
        bn: "ডাউনলোড",
        eu: "deskargatu",
        fi: "ladata",
        sw: "kupakua",
    },
    'Play!': {
        en: "Play!",
        ja: "遊びます!",
        ko: "놀이!",
        zh: "玩!",
        de: "abspielen!",
        fr: "jouer!",
        it: "giocare!",
        es: "¡Jugar!",
        pt: "Toque!",
        ca: "Jugar!",
        ru: "играть!",
        tr: "oyun!",
        nl: "spelen!",
        sv: "spela!",
        id: "bermain!",
        ro: "Joaca!",
        ar: "لعب!",
        uk: "грати!",
        no: "spille!",
        nb: "spille!",
        nn: "spille!",
        he: "לְשַׂחֵק!",
        ms: "Bermain!",
        th: "เล่น!",
        pl: "Grać!",
        be: "Гуляць!",
        el: "Παίζω!",
        bg: "Играйте!",
        da: "Spille!",
        sr: "Игра!",
        kk: "Ойнайық!",
        vi: "Chơi!",
        hr: "Igra!",
        km: "លេង!",
        sq: "Luaj!",
        sl: "Igraj!",
        lt: "Žaisti!",
        az: "Oynamaq!",
        zu: "Dlala!",
        ga: "Seinn!",
        is: "Leika!",
        hu: "Játék!",
        lv: "Spēlēt!",
        ka: "ითამაშეთ!",
        mt: "Play!",
        et: "Mängi!",
        ne: "खेल्नु!",
        bn: "খেলুন!",
        eu: "Jokatu!",
        fi: "Pelata!",
        sw: "Jaribu!",
    },
    'Play': {
        en: "Play",
        ja: "遊びます",
        ko: "놀이",
        zh: "玩",
        de: "Abspielen",
        fr: "Jouer",
        it: "Giocare",
        es: "Jugar",
        pt: "Toque",
        ca: "Jugar",
        ru: "играть",
        tr: "Oyun",
        nl: "Spelen",
        sv: "Spela",
        id: "Bermain",
        ro: "Joaca",
        ar: "لعب",
        uk: "грати",
        no: "Spille",
        nb: "Spille",
        nn: "Spille",
        he: "לְשַׂחֵק",
        ms: "Bermain",
        th: "เล่น",
        pl: "Grać",
        be: "Гуляць",
        el: "Παίζω",
        bg: "Играйте",
        da: "Spille",
        sr: "Игра",
        kk: "Ойнайық",
        vi: "Chơi",
        hr: "Igra",
        km: "លេង",
        sq: "Luaj",
        sl: "Igraj",
        lt: "Žaisti",
        az: "Oynamaq",
        zu: "Dlala",
        ga: "Seinn",
        is: "Leika",
        hu: "Játék",
        lv: "Spēlēt",
        ka: "ითამაშეთ",
        mt: "Play",
        et: "Mängi",
        ne: "खेल्नु",
        bn: "খেলুন",
        eu: "Jokatu",
        fi: "Pelata",
        sw: "Jaribu",
    },
    'Play Now': {
        en: "Play Now",
        ja: "今すぐプレイ",
        ko: "지금 플레이하세요",
        zh: "马上玩",
        de: "Jetzt Spielen",
        fr: "Jouer Maintenant",
        it: "Gioca Ora",
        es: "Juega Ahora",
        pt: "Jogar Agora",
        ca: "Juga Ara",
        ru: "Играйте сейчас",
        th: "เล่นตอนนี้เลย",
        da: "Spil Nu",
        nl: "Speel Nu",
        sv: "Spela Nu",
        no: "Spill Nå",
        el: "Παίξτε τώρα",
    },
    'Play now': {
        en: "Play now",
        ja: "今すぐプレイ",
        ko: "지금 플레이하세요",
        zh: "马上玩",
        de: "Jetzt spielen",
        fr: "Jouer maintenant",
        it: "Gioca ora",
        es: "Juega ahora",
        pt: "Jogar agora",
        ca: "Juga ara",
        ru: "Играйте сейчас",
        th: "เล่นตอนนี้เลย",
        da: "Spil nu",
        nl: "Speel nu",
        sv: "Spela nu",
        no: "Spill nå",
        el: "Παίξτε τώρα",
    },
    'Download now': {
        en: "Download now",
        ja: "今すぐダウンロード",
        ko: "지금 다운로드",
        zh: "立即下載",
        de: "Jetzt downloaden",
        fr: "Télécharger maintenant",
        it: "Scarica ora",
        es: "Descargar ahora",
        pt: "Baixe agora",
        ca: "Descarrega ara",
        ru: "Загрузить сейчас",
        th: "ดาวน์โหลดเลย",
        el: "Κάντε λήψη τώρα",
    },
    'Download Now': {
        en: "Download Now",
        ja: "今すぐダウンロード",
        ko: "지금 다운로드",
        zh: "立即下載",
        de: "Jetzt Downloaden",
        fr: "Télécharger Maintenant",
        it: "Scarica Ora",
        es: "Descargar Ahora",
        pt: "Baixe Agora",
        ca: "Descarrega Ara",
        ru: "Загрузить сейчас",
        th: "ดาวน์โหลดเลย",
        el: "Κάντε λήψη τώρα",
    },
    'Play free': {
        en: "Play free",
        ja: "無料でプレイ",
        ko: "무료 플레이",
        zh: "免费玩",
        de: "Kostenlos Spielen",
        fr: "Jouez gratuitement",
        it: "Gioca gratis",
        es: "Juega gratis",
        pt: "Jogue grátis",
        ca: "Jugar gratis",
        ru: "Играть бесплатно",
        th: "เล่นฟรี",
        el: "Παίξτε δωρεάν",
    },
    'Play Free': {
        en: "Play Free",
        ja: "無料でプレイ",
        ko: "무료 플레이",
        zh: "免费玩",
        de: "Kostenlos Spielen",
        fr: "Jouez Gratuitement",
        it: "Gioca Gratis",
        es: "Juega Gratis",
        pt: "Jogue Grátis",
        ca: "Jugar Gratis",
        ru: "Играть бесплатно",
        th: "เล่นฟรี",
        el: "Παίξτε δωρεάν",
    },
    'Swipe Up': {
        en: "Swipe Up",
        ja: "上にスワイプ",
        ko: "위로 밀기",
        zh: "向上滑动",
        de: "Nach oben wischen",
        fr: "Balayez vers le haut",
        it: "Scorri verso l'alto",
        es: "Desliza hacia arriba",
        pt: "Deslize para cima",
        ca: "Llisca cap amunt",
        ru: "Проведи пальцем вверх",
        el: "Σάρωση προς τα επάνω",
    },
    'Pop the cubes': {
        en: "Pop the cubes",
        ja: "キューブを消そう",
        ko: "큐브를 터트려요",
        zh: "爆裂方块",
        de: "Lass die Würfel platzen",
        fr: "Faites éclater les cubes",
        it: "Fai scoppiare i cubi",
        es: "Explota los cubos",
        pt: "Estourar os cubos",
        ca: "Esclata els cubs",
        ru: "Лопни кубики",
        el: "Σπάσε τους κύβους",
        tr: "Küpleri patlat",
    },
    'Continue': {
        en: "Continue",
        ja: "続行する",
        ko: "계속하기",
        zh: "继续",
        de: "Weiter",
        fr: "Continuer",
        it: "Continua",
        es: "Continuar",
        pt: "Continuar",
        ca: "Continuar",
        ru: "Продолжить",
        el: "Να συνεχίσει",
    },
    'Next level': {
        en: "Next level",
        ja: "次のレベル",
        ko: "다음 레벨",
        zh: "下一关",
        de: "Nächstes Level",
        fr: "Niveau suivant",
        it: "Livello successivo",
        es: "Siguiente nivel",
        pt: "Próximo nível",
        ca: "Següent nivell",
        ru: "Следующий уровень",
        el: "Επόμενο Επίπεδο",
    },
};