(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getLocalisedCta = getLocalisedCta;
var language;

function getBrowserLanguage() {
    var lang;

    if (navigator.userLanguage) {
        lang = navigator.userLanguage;

        if (lang.indexOf('zh') == -1) lang = lang.split("-")[0];else if (lang != 'zh') {

            lang = 'zh-traditional';
        }
    } else if (navigator.language) {

        lang = navigator.language;

        if (lang.indexOf('zh') == -1) lang = lang.split("-")[0];else if (lang != 'zh') {

            lang = 'zh-traditional';
        }
    } else {

        lang = "en";
    }

    return lang;
}

function getLocalisedCta() {
    if (language == null) language = getBrowserLanguage();
    var text = "GET";
    var font = 'myFont';
    var fontSizeMultiplier = 0.4;
    switch (language) {
        case 'ar':
            text = 'شراء';
            break;
        case 'pt':
            text = 'Obter';
            break;
        case 'zh':
            text = '获取';
            break;
        case 'cs':
            text = 'Získat';
            break;
        case 'da':
            text = 'Hent';
            break;
        case 'nl':
            text = 'Downloaden';
            break;
        case 'fi':
            text = 'Lataa';
            break;
        case 'fr':
            text = 'Obtenir';
            break;
        case 'de':
            text = 'Will ich haben';
            break;
        case 'id':
            text = 'Dapatkan';
            break;
        case 'it':
            text = 'Scarica';
            break;
        case 'ms':
            text = 'Dapatkan';
            break;
        case 'pl':
            text = 'Pobierz';
            break;
        case 'ru':
            text = 'Получить';
            break;
        case 'es':
            text = 'Obtener';
            break;
        case 'th':
            text = 'รับ';
            break;
        case 'tr':
            text = 'Edinin';
            break;
        case 'zh-traditional':
            text = '取得';
            break;
        case 'ja':
            text = '入手';
            break;
        case 'ko':
            text = '다운로드하기';
            break;
        case 'nb':
            text = 'Skaff deg';
            break;
        case 'pt':
            text = 'Obter';
            break;
        case 'es':
            text = 'Comprar';
            break;
        case 'sv':
            text = 'Skaffa';
            break;
        case 'vi':
            text = 'Tải';
            break;
        default:
            text = "GET";
    }
    return { 'text': text.toUpperCase(), 'font': font, 'fontSizeMultiplier': fontSizeMultiplier };
}

},{}],2:[function(require,module,exports){
'use strict';

var _videoController = require('./video-controller');

var _videoController2 = _interopRequireDefault(_videoController);

var _autoLocalisationUtil = require('./auto-localisation-util');

var Utils = _interopRequireWildcard(_autoLocalisationUtil);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var videoPath = 'video.mp4';

var staticImgSrc = 'bg-static.jpg';

var from = 0; // video starting point

var to = null; // video ends point, if want it to loop, leave it as null

var previewCarousel; // carousel shoot

var videoController = null;

var muted = true;

var infoContentTop = 10000;
var infoContentBottom = 0;

var contentCloneflag = false;

function main() {

    /////------ CTA ---------//////////

    var text = Utils.getLocalisedCta().text;
    var fontFamily = Utils.getLocalisedCta().font;
    var fontSizeMultiplier = Utils.getLocalisedCta().fontSizeMultiplier;

    var fontSize = document.getElementById('vungle-cta').offsetHeight * fontSizeMultiplier;

    // var fontMarginTop = orientationCheck()=='portrait'? document.getElementById('cta-img').offsetHeight * 0.05 : document.getElementById('cta-img').offsetHeight * 0.3;

    document.getElementById('vungle-cta').style.fontSize = fontSize + 'px';
    // document.getElementById('cta-text').style.top = fontMarginTop + 'px';


    document.getElementById('vungle-cta').style.opacity = 1;

    document.getElementById('vungle-cta').innerHTML = text;

    // document.getElementById('info-content-fixed-cta').innerHTML = text;

    bindCtaClick(document.getElementById('vungle-cta'));

    bindCtaClick(document.getElementById('app-icon'));

    /////------ CTA END ------//////////


    ////------ WINDOW SCROLL --------////// 

    // var infoContentTop = $('#videoBg').position().top + $('#videoBg').height();


    $('#wrap').scroll(function () {

        stickyBanner();
        showScrollIndicator($(this).scrollTop());

        if (infoContentTop <= 0) {
            if ($(this).scrollTop() >= infoContentTop) {

                repositionInfoContent();
            }
        } else {

            $('#info-clone').css('opacity', 0);
            $('#info-content').css('opacity', 1);
        }

        infoContentTop = $('#info-content').offset().top;
    });

    ////------ WINDOW SCROLL END --------////// 
}

function repositionInfoContent() {

    if (!contentCloneflag) {

        $("#info-content").clone().appendTo("#wrap").addClass('fixed').attr('id', 'info-clone');

        $('#info-clone').find('#vungle-cta').attr('id', 'vungle-cta-clone');
        $('#info-clone').find('#app-icon').attr('id', 'app-icon-clone');

        bindCtaClick(document.getElementById('vungle-cta-clone'));
        bindCtaClick(document.getElementById('app-icon-clone'));

        $('#info-content').css('opacity', 0);

        contentCloneflag = true;
    } else {
        $('#info-clone').css('opacity', 1);
        $('#info-content').css('opacity', 0);
    }
}

function bindCtaClick(obj) {
    // console.log(obj.focus);
    // obj.focus();
    obj.addEventListener("click", function () {
        console.log('cta download');
        parent.postMessage('download', '*');
    });
}

// function isElementInViewport(el) {

//     var rect = el.position();

//     return (
//         rect.top + parseInt(el.css('margin-top')) >= (window.innerHeight || document.documentElement.clientHeight))

// }

function stickyBanner() {
    if (document.body.clientWidth > document.body.clientHeight && document.body.clientHeight <= 500) {
        return;
    }

    if ($('#wrap').scrollTop() < infoContentBottom - document.body.clientHeight) {
        $('#info-content').addClass('fixedToBottom');
    } else {
        $('#info-content').removeClass('fixedToBottom');
    }
}

function initCarousel() {

    var d;

    for (var i = 0; i < windowsSettings.carouselImg.length; i++) {

        d = $('<img>');

        d.attr("data-flickity-lazyload", windowsSettings.carouselImg[i]);

        $('#main-carousel').append(d);
    }

    if (previewCarousel == null) {

        previewCarousel = new Flickity(document.querySelector('#main-carousel'), {
            // Gallery Options:
            cellAlign: 'center',
            // contain: true,
            prevNextButtons: true, // Display arrow controls [True or false]
            setGallerySize: false, // DO NOT TOUCH!!
            pageDots: false, // DO NOT TOUCH!!
            wrapAround: true, // Toggle endless scrolling [True or false]
            fullscreen: true,
            lazyLoad: 3,
            accessibility: true,
            // freeScroll: false, // Toggle stickeyness scrolling [True or false]
            autoPlay: 3000, // Set the Delay between switching Items
            initialIndex: 0 // Which Item should be centered first? 
        });
    }

    previewCarousel.on('staticClick', function (event, pointer, cellElement, cellIndex) {
        // console.log(cellIndex);

        previewCarousel.viewFullscreen();
        previewCarousel.select(cellIndex);
    });

    previewCarousel.on('fullscreenChange', function (isFullscreen) {
        if (isFullscreen) {
            // console.log('hide');
            parent.postMessage('hideCloseButton', '*');
        } else {
            if ($(window).scrollTop() < infoContentTop) {
                $('#info-clone').css('opacity', 0);
                $('#info-content').css('opacity', 1);
            }
            // repositionInfoContent();
            console.log($(window).scrollTop());
            console.log($('#info-content').offset().top);
            parent.postMessage('revealCloseButton', '*');
        }
    });
}

function initContent() {
    if (windowsSettings.appName == undefined || windowsSettings.appName == '') {
        console.log('no appName');
    } else {
        $('#app-name').html(windowsSettings.appName);
    }

    if (windowsSettings.callOut == undefined || windowsSettings.callOut == '') {
        console.log('no callOut');
    } else {
        $('#app-callout').html(windowsSettings.callOut);
    }

    if (windowsSettings.stars == undefined || windowsSettings.stars.length < 5) {
        console.log('five stars have to be defined');
    } else {
        var d = $("<div />").appendTo($('#app-stars'));

        var span;
        for (var i = 0; i < windowsSettings.stars.length; i++) {
            console.log("vungle-star-" + windowsSettings.stars[i]);
            span = $("<span />").addClass("star").addClass("vungicon-star-" + windowsSettings.stars[i]);
            span.appendTo(d);
        }
    }

    if (windowsSettings.reviewCounts == undefined || windowsSettings.reviewCounts == '') {
        console.log('no reviewCounts');
    } else {
        $("<span />").addClass("counts").html(windowsSettings.reviewCounts).appendTo($("#app-stars"));
    }

    if (windowsSettings.descriptionContent == undefined || windowsSettings.descriptionContent == '') {
        console.log('no descriptionContent');
    } else {
        $('#info-app-description-content').html(windowsSettings.descriptionContent);
    }

    if (windowsSettings.ESRB == undefined || windowsSettings.ESRB == {}) {
        console.log('no ESRB');
    } else {
        if (windowsSettings.ESRB.image && windowsSettings.ESRB.image == '') {
            console.log('no ESRB image');
        } else {
            $('<img />').attr('src', windowsSettings.ESRB.image).appendTo($('#ESRB'));
        }

        if (windowsSettings.ESRB.text && windowsSettings.ESRB.text == '') {
            console.log('no ESRB text');
        } else {
            $('<p />').html(windowsSettings.ESRB.text).appendTo($('#ESRB'));
        }
    }

    // $('#info-content-fixed')
    //     .append("<img src='app-icon.jpg'>")
    //     .append("<p>" + windowsSettings.appName + "</p>")
    //     // .append("<div>"+windowsSettings.appName+"</div>")
    //     .append("<button id='info-content-fixed-cta'>Get</button>");
}

function showScrollIndicator(currentScroll) {

    if (currentScroll > 10) {
        $('#scrollIndicator').addClass('hide');
    } else {
        $('#scrollIndicator').removeClass('hide');
        $('#scrollIndicator').find('.dot').each(function (index) {
            $(this).addClass('fadeInDown-' + index);
        });
    }
}

window.resize = function () {
    previewCarousel.resize();
    stickyBanner();
};

window.onload = function () {

    //show the video or static image
    if (typeof videoPath !== 'undefined') {
        $('#videoBg').removeClass('hide');

        $('#bg-static-img').addClass('hide');

        videoController = new _videoController2.default('videoBg');

        videoController.play(videoPath, { "from": from, "loop": true, "simple": true });

        videoController.video.onloadedmetadata = function () {

            //init Everything 
            $('body').removeClass('preload');

            infoContentBottom = $('#info-content').position().top + $('#info-content').height() + parseInt($('#info-content').css('margin-top'));
            // console.log('infoContentBottom', infoContentBottom);
            stickyBanner();

            if ($('.vungle-footer').offset().top > $(window).height()) {

                showScrollIndicator(0);
            }
            $('#scrollIndicator').click(function () {
                // if (isElementInViewport($("#info-content"))) {
                // $('#info-content').animate({
                //     scrollTop: 0
                // }, 1000);

                $('#wrap').animate({
                    scrollTop: $("#info-content").offset().top
                }, 800);
                // }
            });

            initContent();
            initCarousel();
            main();
        };
        // updateVideo();


        ////------ MUTE --------////// 

        $('#mute-toggle').removeClass('hide');

        document.getElementById('mute-toggle').addEventListener('pointerdown', function (event) {

            muted = !muted;

            if (muted) {
                videoController.mute();
            } else {
                videoController.unmute();
            }

            $('#iconMuted').toggle(muted);
            $('#iconUnmuted').toggle(!muted);
        });
        /////------ MUTE TOGGLE END --------//////////
    } else {

        $('#videoBg').addClass('hide');

        $('#bg-static-img').removeClass('hide');

        $('#bg-static-img').attr('src', staticImgSrc);
    }

    //show the video or static image END

};

},{"./auto-localisation-util":1,"./video-controller":3}],3:[function(require,module,exports){
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

/*
===Video Controller===
Handles video controls, including playing a video, pausing a video, changing the video source, etc.
-- Doesn't understand anything about the logic behind transitioning between videos or interactive areas. --
*/
var VideoController = function () {
    function VideoController(container) {
        _classCallCheck(this, VideoController);

        this.container = container;
        this.video = document.getElementById(container);

        var sourceElements = document.getElementsByTagName("source");
        if (sourceElements.length == 0) this.source = document.createElement('source');else this.source = sourceElements[0];

        this.video.appendChild(this.source);
        this.video.controls = false;

        this.muted = true;

        // this.initSignals();
    }

    _createClass(VideoController, [{
        key: 'initSignals',
        value: function initSignals() {
            this.onComplete = new Phaser.Signal();
            this.onLoop = new Phaser.Signal();
            // this.video.onwaiting = function() {
            //     console.log("VIDEO WAITING");
            // };
            // this.video.onplaying = function() {
            //     console.log("VIDEO PLAYING");
            // };
        }

        /*
        ==Play==
        Plays specific video.
        Params:
         + video src
         + args: object with optional arguments to configure how to play the video (optional)
            + "loop" : bool  video loops if true
            + "from" : 1     where does the video start playing from
            + "to" : 2       where does the video pause
        */

    }, {
        key: 'play',
        value: function play(src, args) {
            if (this.videoName == undefined || this.videoName != src) {

                this.videoName = src;

                this.source.setAttribute('src', src);

                this.video.load();

                var _this = this;

                this.isReady(function () {

                    _this.video.muted = _this.muted;
                    _this.video.currentTime = 0;
                    _this.video.endTime = 0;
                    _this.video.play();
                    if (args.simple == undefined || !args.simple) _this.initVideoArgs(args);else {
                        _this.video.simple = args.simple;
                        if (args.loop != undefined && args.loop) {

                            _this.video.loop = true;

                            console.log(_this.video);
                        }
                    }
                });
            } else {
                this.initVideoArgs(args);
                this.video.play();
            }
        }

        /*
        ==Update loop==
        Should be called from the endcard state.
        */

    }, {
        key: 'update',
        value: function update() {
            // console.log("Video Controller update");
            this.video.muted = this.muted;
            if (this.videoEnded()) {
                if (this.video.shouldLoop) {
                    this.video.currentTime = this.video.initialTime;
                    this.video.play();

                    if (this.onLoop != null) this.onLoop.dispatch();
                } else {
                    if (!this.video.paused) {
                        this.video.pause();
                    }
                    if (this.onComplete != null) this.onComplete.dispatch();
                }
            }
            if (!this.video.paused && this.videoEnded()) {
                this.video.pause();
                if (this.onComplete != null) this.onComplete.dispatch();
            }
        }
    }, {
        key: 'isReady',
        value: function isReady(cb) {

            this.canplaythrough = function () {

                // readyState 4 indicates video is ready
                if (this.readyState <= 3) {
                    return;
                }

                // unbind canplaythrough event
                this.oncanplaythrough = null;
                return cb();
            };

            this.video.oncanplaythrough = this.canplaythrough;

            // If the video is in the cache of the browser,
            // the 'canplaythrough' event might have been triggered
            // before we registered the event handler.
            if (this.video.readyState > 3) {

                // unbind canplaythrough event
                this.oncanplaythrough = null;

                return cb();
            }
        }

        /*
        Returns if video has ended.
        This includes full-length of video (if no from/to args have been defined), or specified fragment (from/to).
        */

    }, {
        key: 'videoEnded',
        value: function videoEnded() {
            return this.video.ended || this.video.endTime != 0 && this.video.currentTime >= this.video.endTime;
        }

        /*
        Processes and loads video args into class settings
        */

    }, {
        key: 'initVideoArgs',
        value: function initVideoArgs(args) {
            if (args !== undefined) {

                if (args.from !== undefined && args.to !== undefined) {
                    this.video.initialTime = args.from;
                    this.video.currentTime = args.from;
                    this.video.endTime = args.to !== undefined ? args.to : 0;
                } else if (args.from !== undefined) {
                    this.video.initialTime = args.from;
                    this.video.currentTime = args.from;
                    this.video.endTime = 0;
                }
                if (args.loop !== undefined && typeof args.loop == 'boolean') {
                    this.video.shouldLoop = args.loop;
                } else {
                    this.video.shouldLoop = false;
                }
            }
        }
    }, {
        key: 'unmute',
        value: function unmute() {

            if (this.video.simple) {
                this.video.muted = false;
            } else {
                this.muted = false;
            }
            console.log(this.video);
        }
    }, {
        key: 'mute',
        value: function mute() {

            if (this.video.simple) {
                this.video.muted = true;
            } else {
                this.muted = true;
            }
            console.log(this.video);
        }
    }, {
        key: 'pause',
        value: function pause() {
            this.mute();
            this.video.pause();
            this.pausedCurrentTime = this.video.currentTime;
        }
    }, {
        key: 'isPaused',
        value: function isPaused() {
            return this.video.paused;
        }
    }, {
        key: 'resume',
        value: function resume() {
            this.unmute();
            if (this.pausedCurrentTime) this.video.currentTime = this.pausedCurrentTime;
            this.video.play();
        }
    }]);

    return VideoController;
}();

exports.default = VideoController;

},{}]},{},[2])
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJidWlsZHMvc3JjL2F1dG8tbG9jYWxpc2F0aW9uLXV0aWwuanMiLCJidWlsZHMvc3JjL21haW4uanMiLCJidWlsZHMvc3JjL3ZpZGVvLWNvbnRyb2xsZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7OztRQ3VDZ0IsZSxHQUFBLGU7QUF2Q2hCLElBQUksUUFBSjs7QUFFQSxTQUFTLGtCQUFULEdBQThCO0FBQzFCLFFBQUksSUFBSjs7QUFFQSxRQUFJLFVBQVUsWUFBZCxFQUE0QjtBQUN4QixlQUFPLFVBQVUsWUFBakI7O0FBRUEsWUFBSSxLQUFLLE9BQUwsQ0FBYSxJQUFiLEtBQXNCLENBQUMsQ0FBM0IsRUFFSSxPQUFPLEtBQUssS0FBTCxDQUFXLEdBQVgsRUFBZ0IsQ0FBaEIsQ0FBUCxDQUZKLEtBSUssSUFBSSxRQUFRLElBQVosRUFBa0I7O0FBRW5CLG1CQUFPLGdCQUFQO0FBQ0g7QUFDSixLQVhELE1BV08sSUFBSSxVQUFVLFFBQWQsRUFBd0I7O0FBRTNCLGVBQU8sVUFBVSxRQUFqQjs7QUFHQSxZQUFJLEtBQUssT0FBTCxDQUFhLElBQWIsS0FBc0IsQ0FBQyxDQUEzQixFQUVJLE9BQU8sS0FBSyxLQUFMLENBQVcsR0FBWCxFQUFnQixDQUFoQixDQUFQLENBRkosS0FJSyxJQUFJLFFBQVEsSUFBWixFQUFrQjs7QUFFbkIsbUJBQU8sZ0JBQVA7QUFFSDtBQUNKLEtBZE0sTUFjQTs7QUFFSCxlQUFPLElBQVA7QUFDSDs7QUFFRCxXQUFPLElBQVA7QUFFSDs7QUFFTSxTQUFTLGVBQVQsR0FBMkI7QUFDOUIsUUFBSSxZQUFZLElBQWhCLEVBQ0ksV0FBVyxvQkFBWDtBQUNKLFFBQUksT0FBTyxLQUFYO0FBQ0EsUUFBSSxPQUFPLFFBQVg7QUFDQSxRQUFJLHFCQUFxQixHQUF6QjtBQUNBLFlBQVEsUUFBUjtBQUNJLGFBQUssSUFBTDtBQUNJLG1CQUFPLE1BQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLE9BQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLElBQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLFFBQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLE1BQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLFlBQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLE9BQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLFNBQVA7QUFDQTtBQUNKLGFBQUssSUFBTDtBQUNJLG1CQUFPLGdCQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxVQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxTQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxVQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxTQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxVQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxTQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxLQUFQO0FBQ0E7QUFDSixhQUFLLElBQUw7QUFDSSxtQkFBTyxRQUFQO0FBQ0E7QUFDSixhQUFLLGdCQUFMO0FBQ0ksbUJBQU8sSUFBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sSUFBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sUUFBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sV0FBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sT0FBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sU0FBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sUUFBUDtBQUNBO0FBQ0osYUFBSyxJQUFMO0FBQ0ksbUJBQU8sS0FBUDtBQUNBO0FBQ0o7QUFDSSxtQkFBTyxLQUFQO0FBN0VSO0FBK0VBLFdBQU8sRUFBRSxRQUFRLEtBQUssV0FBTCxFQUFWLEVBQThCLFFBQVEsSUFBdEMsRUFBNEMsc0JBQXNCLGtCQUFsRSxFQUFQO0FBQ0g7Ozs7O0FDN0hEOzs7O0FBQ0E7O0lBQVksSzs7Ozs7O0FBRVosSUFBSSxZQUFZLFdBQWhCOztBQUVBLElBQUksZUFBZSxlQUFuQjs7QUFFQSxJQUFJLE9BQU8sQ0FBWCxDLENBQWM7O0FBRWQsSUFBSSxLQUFLLElBQVQsQyxDQUFlOztBQUVmLElBQUksZUFBSixDLENBQXFCOztBQUVyQixJQUFJLGtCQUFrQixJQUF0Qjs7QUFFQSxJQUFJLFFBQVEsSUFBWjs7QUFFQSxJQUFJLGlCQUFpQixLQUFyQjtBQUNBLElBQUksb0JBQW9CLENBQXhCOztBQUVBLElBQUksbUJBQW1CLEtBQXZCOztBQUVBLFNBQVMsSUFBVCxHQUFnQjs7QUFHWjs7QUFFQSxRQUFJLE9BQU8sTUFBTSxlQUFOLEdBQXdCLElBQW5DO0FBQ0EsUUFBSSxhQUFhLE1BQU0sZUFBTixHQUF3QixJQUF6QztBQUNBLFFBQUkscUJBQXFCLE1BQU0sZUFBTixHQUF3QixrQkFBakQ7O0FBRUEsUUFBSSxXQUFXLFNBQVMsY0FBVCxDQUF3QixZQUF4QixFQUFzQyxZQUF0QyxHQUFxRCxrQkFBcEU7O0FBSUE7O0FBRUEsYUFBUyxjQUFULENBQXdCLFlBQXhCLEVBQXNDLEtBQXRDLENBQTRDLFFBQTVDLEdBQXVELFdBQVcsSUFBbEU7QUFDQTs7O0FBR0EsYUFBUyxjQUFULENBQXdCLFlBQXhCLEVBQXNDLEtBQXRDLENBQTRDLE9BQTVDLEdBQXNELENBQXREOztBQUVBLGFBQVMsY0FBVCxDQUF3QixZQUF4QixFQUFzQyxTQUF0QyxHQUFrRCxJQUFsRDs7QUFFQTs7QUFFQSxpQkFBYSxTQUFTLGNBQVQsQ0FBd0IsWUFBeEIsQ0FBYjs7QUFFQSxpQkFBYSxTQUFTLGNBQVQsQ0FBd0IsVUFBeEIsQ0FBYjs7QUFHQTs7O0FBS0E7O0FBRUE7OztBQUlBLE1BQUUsT0FBRixFQUFXLE1BQVgsQ0FBa0IsWUFBVzs7QUFFekI7QUFDQSw0QkFBb0IsRUFBRSxJQUFGLEVBQVEsU0FBUixFQUFwQjs7QUFFQSxZQUFJLGtCQUFrQixDQUF0QixFQUF5QjtBQUNyQixnQkFBSSxFQUFFLElBQUYsRUFBUSxTQUFSLE1BQXVCLGNBQTNCLEVBQTJDOztBQUV2QztBQUNIO0FBRUosU0FORCxNQU1POztBQUVILGNBQUUsYUFBRixFQUFpQixHQUFqQixDQUFxQixTQUFyQixFQUFnQyxDQUFoQztBQUNBLGNBQUUsZUFBRixFQUFtQixHQUFuQixDQUF1QixTQUF2QixFQUFrQyxDQUFsQztBQUNIOztBQUVELHlCQUFpQixFQUFFLGVBQUYsRUFBbUIsTUFBbkIsR0FBNEIsR0FBN0M7QUFJSCxLQXJCRDs7QUF3QkE7QUFFSDs7QUFFRCxTQUFTLHFCQUFULEdBQWlDOztBQUU3QixRQUFJLENBQUMsZ0JBQUwsRUFBdUI7O0FBRW5CLFVBQUUsZUFBRixFQUFtQixLQUFuQixHQUEyQixRQUEzQixDQUFvQyxPQUFwQyxFQUE2QyxRQUE3QyxDQUFzRCxPQUF0RCxFQUErRCxJQUEvRCxDQUFvRSxJQUFwRSxFQUEwRSxZQUExRTs7QUFFQSxVQUFFLGFBQUYsRUFBaUIsSUFBakIsQ0FBc0IsYUFBdEIsRUFBcUMsSUFBckMsQ0FBMEMsSUFBMUMsRUFBZ0Qsa0JBQWhEO0FBQ0EsVUFBRSxhQUFGLEVBQWlCLElBQWpCLENBQXNCLFdBQXRCLEVBQW1DLElBQW5DLENBQXdDLElBQXhDLEVBQThDLGdCQUE5Qzs7QUFFQSxxQkFBYSxTQUFTLGNBQVQsQ0FBd0Isa0JBQXhCLENBQWI7QUFDQSxxQkFBYSxTQUFTLGNBQVQsQ0FBd0IsZ0JBQXhCLENBQWI7O0FBRUEsVUFBRSxlQUFGLEVBQW1CLEdBQW5CLENBQXVCLFNBQXZCLEVBQWtDLENBQWxDOztBQUVBLDJCQUFtQixJQUFuQjtBQUNILEtBYkQsTUFhTztBQUNILFVBQUUsYUFBRixFQUFpQixHQUFqQixDQUFxQixTQUFyQixFQUFnQyxDQUFoQztBQUNBLFVBQUUsZUFBRixFQUFtQixHQUFuQixDQUF1QixTQUF2QixFQUFrQyxDQUFsQztBQUVIO0FBQ0o7O0FBRUQsU0FBUyxZQUFULENBQXNCLEdBQXRCLEVBQTJCO0FBQ3ZCO0FBQ0E7QUFDQSxRQUFJLGdCQUFKLENBQXFCLE9BQXJCLEVBQThCLFlBQVc7QUFDckMsZ0JBQVEsR0FBUixDQUFZLGNBQVo7QUFDQSxlQUFPLFdBQVAsQ0FBbUIsVUFBbkIsRUFBK0IsR0FBL0I7QUFDSCxLQUhEO0FBS0g7O0FBR0Q7O0FBRUE7O0FBRUE7QUFDQTs7QUFFQTs7QUFFQSxTQUFTLFlBQVQsR0FBd0I7QUFDcEIsUUFBRyxTQUFTLElBQVQsQ0FBYyxXQUFkLEdBQTRCLFNBQVMsSUFBVCxDQUFjLFlBQTFDLElBQTBELFNBQVMsSUFBVCxDQUFjLFlBQWQsSUFBOEIsR0FBM0YsRUFBK0Y7QUFDM0Y7QUFDSDs7QUFFRCxRQUFJLEVBQUUsT0FBRixFQUFXLFNBQVgsS0FBeUIsb0JBQW9CLFNBQVMsSUFBVCxDQUFjLFlBQS9ELEVBQTZFO0FBQ3pFLFVBQUUsZUFBRixFQUFtQixRQUFuQixDQUE0QixlQUE1QjtBQUNILEtBRkQsTUFFTztBQUNILFVBQUUsZUFBRixFQUFtQixXQUFuQixDQUErQixlQUEvQjtBQUNIO0FBR0o7O0FBSUQsU0FBUyxZQUFULEdBQXdCOztBQUVwQixRQUFJLENBQUo7O0FBRUEsU0FBSyxJQUFJLElBQUksQ0FBYixFQUFnQixJQUFJLGdCQUFnQixXQUFoQixDQUE0QixNQUFoRCxFQUF3RCxHQUF4RCxFQUE2RDs7QUFFekQsWUFBSSxFQUFFLE9BQUYsQ0FBSjs7QUFFQSxVQUFFLElBQUYsQ0FBTyx3QkFBUCxFQUFpQyxnQkFBZ0IsV0FBaEIsQ0FBNEIsQ0FBNUIsQ0FBakM7O0FBRUEsVUFBRSxnQkFBRixFQUFvQixNQUFwQixDQUEyQixDQUEzQjtBQUNIOztBQUVELFFBQUksbUJBQW1CLElBQXZCLEVBQTZCOztBQUV6QiwwQkFBa0IsSUFBSSxRQUFKLENBQWEsU0FBUyxhQUFULENBQXVCLGdCQUF2QixDQUFiLEVBQXVEO0FBQ3JFO0FBQ0EsdUJBQVcsUUFGMEQ7QUFHckU7QUFDQSw2QkFBaUIsSUFKb0QsRUFJOUM7QUFDdkIsNEJBQWdCLEtBTHFELEVBSzlDO0FBQ3ZCLHNCQUFVLEtBTjJELEVBTXBEO0FBQ2pCLHdCQUFZLElBUHlELEVBT25EO0FBQ2xCLHdCQUFZLElBUnlEO0FBU3JFLHNCQUFVLENBVDJEO0FBVXJFLDJCQUFlLElBVnNEO0FBV3JFO0FBQ0Esc0JBQVUsSUFaMkQsRUFZckQ7QUFDaEIsMEJBQWMsQ0FidUQsQ0FhckQ7QUFicUQsU0FBdkQsQ0FBbEI7QUFlSDs7QUFFRCxvQkFBZ0IsRUFBaEIsQ0FBbUIsYUFBbkIsRUFBa0MsVUFBUyxLQUFULEVBQWdCLE9BQWhCLEVBQXlCLFdBQXpCLEVBQXNDLFNBQXRDLEVBQWlEO0FBQy9FOztBQUVBLHdCQUFnQixjQUFoQjtBQUNBLHdCQUFnQixNQUFoQixDQUF1QixTQUF2QjtBQUVILEtBTkQ7O0FBUUEsb0JBQWdCLEVBQWhCLENBQW1CLGtCQUFuQixFQUF1QyxVQUFTLFlBQVQsRUFBdUI7QUFDMUQsWUFBSSxZQUFKLEVBQWtCO0FBQ2Q7QUFDQSxtQkFBTyxXQUFQLENBQW1CLGlCQUFuQixFQUFzQyxHQUF0QztBQUVILFNBSkQsTUFJTztBQUNILGdCQUFJLEVBQUUsTUFBRixFQUFVLFNBQVYsS0FBd0IsY0FBNUIsRUFBNEM7QUFDeEMsa0JBQUUsYUFBRixFQUFpQixHQUFqQixDQUFxQixTQUFyQixFQUFnQyxDQUFoQztBQUNBLGtCQUFFLGVBQUYsRUFBbUIsR0FBbkIsQ0FBdUIsU0FBdkIsRUFBa0MsQ0FBbEM7QUFDSDtBQUNEO0FBQ0Esb0JBQVEsR0FBUixDQUFZLEVBQUUsTUFBRixFQUFVLFNBQVYsRUFBWjtBQUNBLG9CQUFRLEdBQVIsQ0FBWSxFQUFFLGVBQUYsRUFBbUIsTUFBbkIsR0FBNEIsR0FBeEM7QUFDQSxtQkFBTyxXQUFQLENBQW1CLG1CQUFuQixFQUF3QyxHQUF4QztBQUNIO0FBQ0osS0FmRDtBQWdCSDs7QUFHRCxTQUFTLFdBQVQsR0FBdUI7QUFDbkIsUUFBSSxnQkFBZ0IsT0FBaEIsSUFBMkIsU0FBM0IsSUFBd0MsZ0JBQWdCLE9BQWhCLElBQTJCLEVBQXZFLEVBQTJFO0FBQ3ZFLGdCQUFRLEdBQVIsQ0FBWSxZQUFaO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsVUFBRSxXQUFGLEVBQWUsSUFBZixDQUFvQixnQkFBZ0IsT0FBcEM7QUFDSDs7QUFHRCxRQUFJLGdCQUFnQixPQUFoQixJQUEyQixTQUEzQixJQUF3QyxnQkFBZ0IsT0FBaEIsSUFBMkIsRUFBdkUsRUFBMkU7QUFDdkUsZ0JBQVEsR0FBUixDQUFZLFlBQVo7QUFDSCxLQUZELE1BRU87QUFDSCxVQUFFLGNBQUYsRUFBa0IsSUFBbEIsQ0FBdUIsZ0JBQWdCLE9BQXZDO0FBQ0g7O0FBRUQsUUFBSSxnQkFBZ0IsS0FBaEIsSUFBeUIsU0FBekIsSUFBc0MsZ0JBQWdCLEtBQWhCLENBQXNCLE1BQXRCLEdBQStCLENBQXpFLEVBQTRFO0FBQ3hFLGdCQUFRLEdBQVIsQ0FBWSwrQkFBWjtBQUNILEtBRkQsTUFFTztBQUNILFlBQUksSUFBSSxFQUFFLFNBQUYsRUFBYSxRQUFiLENBQXNCLEVBQUUsWUFBRixDQUF0QixDQUFSOztBQUVBLFlBQUksSUFBSjtBQUNBLGFBQUssSUFBSSxJQUFJLENBQWIsRUFBZ0IsSUFBSSxnQkFBZ0IsS0FBaEIsQ0FBc0IsTUFBMUMsRUFBa0QsR0FBbEQsRUFBdUQ7QUFDbkQsb0JBQVEsR0FBUixDQUFZLGlCQUFpQixnQkFBZ0IsS0FBaEIsQ0FBc0IsQ0FBdEIsQ0FBN0I7QUFDQSxtQkFBTyxFQUFFLFVBQUYsRUFBYyxRQUFkLENBQXVCLE1BQXZCLEVBQStCLFFBQS9CLENBQXdDLG1CQUFtQixnQkFBZ0IsS0FBaEIsQ0FBc0IsQ0FBdEIsQ0FBM0QsQ0FBUDtBQUNBLGlCQUFLLFFBQUwsQ0FBYyxDQUFkO0FBQ0g7QUFFSjs7QUFFRCxRQUFJLGdCQUFnQixZQUFoQixJQUFnQyxTQUFoQyxJQUE2QyxnQkFBZ0IsWUFBaEIsSUFBZ0MsRUFBakYsRUFBcUY7QUFDakYsZ0JBQVEsR0FBUixDQUFZLGlCQUFaO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsVUFBRSxVQUFGLEVBQWMsUUFBZCxDQUF1QixRQUF2QixFQUFpQyxJQUFqQyxDQUFzQyxnQkFBZ0IsWUFBdEQsRUFBb0UsUUFBcEUsQ0FBNkUsRUFBRSxZQUFGLENBQTdFO0FBR0g7O0FBSUQsUUFBSSxnQkFBZ0Isa0JBQWhCLElBQXNDLFNBQXRDLElBQW1ELGdCQUFnQixrQkFBaEIsSUFBc0MsRUFBN0YsRUFBaUc7QUFDN0YsZ0JBQVEsR0FBUixDQUFZLHVCQUFaO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsVUFBRSwrQkFBRixFQUFtQyxJQUFuQyxDQUF3QyxnQkFBZ0Isa0JBQXhEO0FBQ0g7O0FBR0QsUUFBSSxnQkFBZ0IsSUFBaEIsSUFBd0IsU0FBeEIsSUFBcUMsZ0JBQWdCLElBQWhCLElBQXdCLEVBQWpFLEVBQXFFO0FBQ2pFLGdCQUFRLEdBQVIsQ0FBWSxTQUFaO0FBQ0gsS0FGRCxNQUVPO0FBQ0gsWUFBSSxnQkFBZ0IsSUFBaEIsQ0FBcUIsS0FBckIsSUFBOEIsZ0JBQWdCLElBQWhCLENBQXFCLEtBQXJCLElBQThCLEVBQWhFLEVBQW9FO0FBQ2hFLG9CQUFRLEdBQVIsQ0FBWSxlQUFaO0FBQ0gsU0FGRCxNQUVPO0FBQ0gsY0FBRSxTQUFGLEVBQWEsSUFBYixDQUFrQixLQUFsQixFQUF5QixnQkFBZ0IsSUFBaEIsQ0FBcUIsS0FBOUMsRUFBcUQsUUFBckQsQ0FBOEQsRUFBRSxPQUFGLENBQTlEO0FBQ0g7O0FBR0QsWUFBSSxnQkFBZ0IsSUFBaEIsQ0FBcUIsSUFBckIsSUFBNkIsZ0JBQWdCLElBQWhCLENBQXFCLElBQXJCLElBQTZCLEVBQTlELEVBQWtFO0FBQzlELG9CQUFRLEdBQVIsQ0FBWSxjQUFaO0FBQ0gsU0FGRCxNQUVPO0FBQ0gsY0FBRSxPQUFGLEVBQVcsSUFBWCxDQUFnQixnQkFBZ0IsSUFBaEIsQ0FBcUIsSUFBckMsRUFBMkMsUUFBM0MsQ0FBb0QsRUFBRSxPQUFGLENBQXBEO0FBQ0g7QUFHSjs7QUFFRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUg7O0FBR0QsU0FBUyxtQkFBVCxDQUE2QixhQUE3QixFQUE0Qzs7QUFFeEMsUUFBSSxnQkFBZ0IsRUFBcEIsRUFBd0I7QUFDcEIsVUFBRSxrQkFBRixFQUFzQixRQUF0QixDQUErQixNQUEvQjtBQUNILEtBRkQsTUFFTztBQUNILFVBQUUsa0JBQUYsRUFBc0IsV0FBdEIsQ0FBa0MsTUFBbEM7QUFDQSxVQUFFLGtCQUFGLEVBQXNCLElBQXRCLENBQTJCLE1BQTNCLEVBQW1DLElBQW5DLENBQXdDLFVBQVMsS0FBVCxFQUFnQjtBQUNwRCxjQUFFLElBQUYsRUFBUSxRQUFSLENBQWlCLGdCQUFnQixLQUFqQztBQUNILFNBRkQ7QUFHSDtBQUNKOztBQUVELE9BQU8sTUFBUCxHQUFnQixZQUFXO0FBQ3ZCLG9CQUFnQixNQUFoQjtBQUNBO0FBRUgsQ0FKRDs7QUFNQSxPQUFPLE1BQVAsR0FBZ0IsWUFBVzs7QUFHdkI7QUFDQSxRQUFJLE9BQU8sU0FBUCxLQUFxQixXQUF6QixFQUFzQztBQUNsQyxVQUFFLFVBQUYsRUFBYyxXQUFkLENBQTBCLE1BQTFCOztBQUVBLFVBQUUsZ0JBQUYsRUFBb0IsUUFBcEIsQ0FBNkIsTUFBN0I7O0FBRUEsMEJBQWtCLElBQUkseUJBQUosQ0FBb0IsU0FBcEIsQ0FBbEI7O0FBRUEsd0JBQWdCLElBQWhCLENBQXFCLFNBQXJCLEVBQWdDLEVBQUUsUUFBUSxJQUFWLEVBQWdCLFFBQVEsSUFBeEIsRUFBOEIsVUFBVSxJQUF4QyxFQUFoQzs7QUFHQSx3QkFBZ0IsS0FBaEIsQ0FBc0IsZ0JBQXRCLEdBQXlDLFlBQVc7O0FBRWhEO0FBQ0EsY0FBRSxNQUFGLEVBQVUsV0FBVixDQUFzQixTQUF0Qjs7QUFHQSxnQ0FBb0IsRUFBRSxlQUFGLEVBQW1CLFFBQW5CLEdBQThCLEdBQTlCLEdBQW9DLEVBQUUsZUFBRixFQUFtQixNQUFuQixFQUFwQyxHQUFrRSxTQUFTLEVBQUUsZUFBRixFQUFtQixHQUFuQixDQUF1QixZQUF2QixDQUFULENBQXRGO0FBQ0E7QUFDQTs7QUFJQSxnQkFBSSxFQUFFLGdCQUFGLEVBQW9CLE1BQXBCLEdBQTZCLEdBQTdCLEdBQW1DLEVBQUUsTUFBRixFQUFVLE1BQVYsRUFBdkMsRUFBMkQ7O0FBR3ZELG9DQUFvQixDQUFwQjtBQUVIO0FBQ0QsY0FBRSxrQkFBRixFQUFzQixLQUF0QixDQUE0QixZQUFXO0FBQ25DO0FBQ0k7QUFDQTtBQUNBOztBQUVBLGtCQUFFLE9BQUYsRUFBVyxPQUFYLENBQW1CO0FBQ2YsK0JBQVcsRUFBRSxlQUFGLEVBQW1CLE1BQW5CLEdBQTRCO0FBRHhCLGlCQUFuQixFQUVHLEdBRkg7QUFHSjtBQUNILGFBVkQ7O0FBWUE7QUFDQTtBQUNBO0FBQ0gsU0FqQ0Q7QUFrQ0E7OztBQUdBOztBQUVBLFVBQUUsY0FBRixFQUFrQixXQUFsQixDQUE4QixNQUE5Qjs7QUFFQSxpQkFBUyxjQUFULENBQXdCLGFBQXhCLEVBQXVDLGdCQUF2QyxDQUF3RCxhQUF4RCxFQUF1RSxVQUFTLEtBQVQsRUFBZ0I7O0FBRW5GLG9CQUFRLENBQUMsS0FBVDs7QUFFQSxnQkFBSSxLQUFKLEVBQVc7QUFDUCxnQ0FBZ0IsSUFBaEI7QUFDSCxhQUZELE1BRU87QUFDSCxnQ0FBZ0IsTUFBaEI7QUFDSDs7QUFFRCxjQUFFLFlBQUYsRUFBZ0IsTUFBaEIsQ0FBdUIsS0FBdkI7QUFDQSxjQUFFLGNBQUYsRUFBa0IsTUFBbEIsQ0FBeUIsQ0FBQyxLQUExQjtBQUNILFNBWkQ7QUFhQTtBQUVILEtBbEVELE1Ba0VPOztBQUVILFVBQUUsVUFBRixFQUFjLFFBQWQsQ0FBdUIsTUFBdkI7O0FBRUEsVUFBRSxnQkFBRixFQUFvQixXQUFwQixDQUFnQyxNQUFoQzs7QUFFQSxVQUFFLGdCQUFGLEVBQW9CLElBQXBCLENBQXlCLEtBQXpCLEVBQWdDLFlBQWhDO0FBQ0g7O0FBR0Q7O0FBSUgsQ0FwRkQ7Ozs7Ozs7Ozs7Ozs7QUMzU0E7Ozs7O0lBS00sZTtBQUVGLDZCQUFZLFNBQVosRUFBdUI7QUFBQTs7QUFFbkIsYUFBSyxTQUFMLEdBQWlCLFNBQWpCO0FBQ0EsYUFBSyxLQUFMLEdBQWEsU0FBUyxjQUFULENBQXdCLFNBQXhCLENBQWI7O0FBRUEsWUFBSSxpQkFBaUIsU0FBUyxvQkFBVCxDQUE4QixRQUE5QixDQUFyQjtBQUNBLFlBQUksZUFBZSxNQUFmLElBQXlCLENBQTdCLEVBQ0ksS0FBSyxNQUFMLEdBQWMsU0FBUyxhQUFULENBQXVCLFFBQXZCLENBQWQsQ0FESixLQUdJLEtBQUssTUFBTCxHQUFjLGVBQWUsQ0FBZixDQUFkOztBQUVKLGFBQUssS0FBTCxDQUFXLFdBQVgsQ0FBdUIsS0FBSyxNQUE1QjtBQUNBLGFBQUssS0FBTCxDQUFXLFFBQVgsR0FBc0IsS0FBdEI7O0FBRUEsYUFBSyxLQUFMLEdBQWEsSUFBYjs7QUFFQTtBQUVIOzs7O3NDQUVhO0FBQ1YsaUJBQUssVUFBTCxHQUFrQixJQUFJLE9BQU8sTUFBWCxFQUFsQjtBQUNBLGlCQUFLLE1BQUwsR0FBYyxJQUFJLE9BQU8sTUFBWCxFQUFkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0g7O0FBRUQ7Ozs7Ozs7Ozs7Ozs7NkJBVUssRyxFQUFLLEksRUFBTTtBQUNaLGdCQUFJLEtBQUssU0FBTCxJQUFrQixTQUFsQixJQUErQixLQUFLLFNBQUwsSUFBa0IsR0FBckQsRUFBMEQ7O0FBRXRELHFCQUFLLFNBQUwsR0FBaUIsR0FBakI7O0FBRUEscUJBQUssTUFBTCxDQUFZLFlBQVosQ0FBeUIsS0FBekIsRUFBZ0MsR0FBaEM7O0FBRUEscUJBQUssS0FBTCxDQUFXLElBQVg7O0FBSUEsb0JBQUksUUFBUSxJQUFaOztBQUVBLHFCQUFLLE9BQUwsQ0FBYSxZQUFXOztBQUVwQiwwQkFBTSxLQUFOLENBQVksS0FBWixHQUFvQixNQUFNLEtBQTFCO0FBQ0EsMEJBQU0sS0FBTixDQUFZLFdBQVosR0FBMEIsQ0FBMUI7QUFDQSwwQkFBTSxLQUFOLENBQVksT0FBWixHQUFzQixDQUF0QjtBQUNBLDBCQUFNLEtBQU4sQ0FBWSxJQUFaO0FBQ0Esd0JBQUksS0FBSyxNQUFMLElBQWUsU0FBZixJQUE0QixDQUFDLEtBQUssTUFBdEMsRUFDSSxNQUFNLGFBQU4sQ0FBb0IsSUFBcEIsRUFESixLQUVLO0FBQ0QsOEJBQU0sS0FBTixDQUFZLE1BQVosR0FBcUIsS0FBSyxNQUExQjtBQUNBLDRCQUFJLEtBQUssSUFBTCxJQUFhLFNBQWIsSUFBMEIsS0FBSyxJQUFuQyxFQUF5Qzs7QUFFckMsa0NBQU0sS0FBTixDQUFZLElBQVosR0FBbUIsSUFBbkI7O0FBRUEsb0NBQVEsR0FBUixDQUFZLE1BQU0sS0FBbEI7QUFDSDtBQUNKO0FBQ0osaUJBakJEO0FBbUJILGFBL0JELE1BK0JPO0FBQ0gscUJBQUssYUFBTCxDQUFtQixJQUFuQjtBQUNBLHFCQUFLLEtBQUwsQ0FBVyxJQUFYO0FBQ0g7QUFDSjs7QUFFRDs7Ozs7OztpQ0FJUztBQUNMO0FBQ0EsaUJBQUssS0FBTCxDQUFXLEtBQVgsR0FBbUIsS0FBSyxLQUF4QjtBQUNBLGdCQUFJLEtBQUssVUFBTCxFQUFKLEVBQXVCO0FBQ25CLG9CQUFJLEtBQUssS0FBTCxDQUFXLFVBQWYsRUFBMkI7QUFDdkIseUJBQUssS0FBTCxDQUFXLFdBQVgsR0FBeUIsS0FBSyxLQUFMLENBQVcsV0FBcEM7QUFDQSx5QkFBSyxLQUFMLENBQVcsSUFBWDs7QUFFQSx3QkFBSSxLQUFLLE1BQUwsSUFBZSxJQUFuQixFQUNJLEtBQUssTUFBTCxDQUFZLFFBQVo7QUFDUCxpQkFORCxNQU1PO0FBQ0gsd0JBQUksQ0FBQyxLQUFLLEtBQUwsQ0FBVyxNQUFoQixFQUF3QjtBQUNwQiw2QkFBSyxLQUFMLENBQVcsS0FBWDtBQUNIO0FBQ0Qsd0JBQUksS0FBSyxVQUFMLElBQW1CLElBQXZCLEVBQ0ksS0FBSyxVQUFMLENBQWdCLFFBQWhCO0FBQ1A7QUFDSjtBQUNELGdCQUFJLENBQUMsS0FBSyxLQUFMLENBQVcsTUFBWixJQUFzQixLQUFLLFVBQUwsRUFBMUIsRUFBNkM7QUFDekMscUJBQUssS0FBTCxDQUFXLEtBQVg7QUFDQSxvQkFBSSxLQUFLLFVBQUwsSUFBbUIsSUFBdkIsRUFDSSxLQUFLLFVBQUwsQ0FBZ0IsUUFBaEI7QUFDUDtBQUNKOzs7Z0NBRU8sRSxFQUFJOztBQUVSLGlCQUFLLGNBQUwsR0FBc0IsWUFBVzs7QUFFN0I7QUFDQSxvQkFBSSxLQUFLLFVBQUwsSUFBbUIsQ0FBdkIsRUFBMEI7QUFDdEI7QUFDSDs7QUFFRDtBQUNBLHFCQUFLLGdCQUFMLEdBQXdCLElBQXhCO0FBQ0EsdUJBQU8sSUFBUDtBQUNILGFBVkQ7O0FBWUEsaUJBQUssS0FBTCxDQUFXLGdCQUFYLEdBQThCLEtBQUssY0FBbkM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0JBQUksS0FBSyxLQUFMLENBQVcsVUFBWCxHQUF3QixDQUE1QixFQUErQjs7QUFFM0I7QUFDQSxxQkFBSyxnQkFBTCxHQUF3QixJQUF4Qjs7QUFFQSx1QkFBTyxJQUFQO0FBQ0g7QUFDSjs7QUFFRDs7Ozs7OztxQ0FJYTtBQUNULG1CQUFPLEtBQUssS0FBTCxDQUFXLEtBQVgsSUFBb0IsS0FBSyxLQUFMLENBQVcsT0FBWCxJQUFzQixDQUF0QixJQUEyQixLQUFLLEtBQUwsQ0FBVyxXQUFYLElBQTBCLEtBQUssS0FBTCxDQUFXLE9BQTNGO0FBQ0g7O0FBRUQ7Ozs7OztzQ0FHYyxJLEVBQU07QUFDaEIsZ0JBQUksU0FBUyxTQUFiLEVBQXdCOztBQUVwQixvQkFBSSxLQUFLLElBQUwsS0FBYyxTQUFkLElBQTJCLEtBQUssRUFBTCxLQUFZLFNBQTNDLEVBQXNEO0FBQ2xELHlCQUFLLEtBQUwsQ0FBVyxXQUFYLEdBQXlCLEtBQUssSUFBOUI7QUFDQSx5QkFBSyxLQUFMLENBQVcsV0FBWCxHQUF5QixLQUFLLElBQTlCO0FBQ0EseUJBQUssS0FBTCxDQUFXLE9BQVgsR0FBcUIsS0FBSyxFQUFMLEtBQVksU0FBWixHQUF3QixLQUFLLEVBQTdCLEdBQWtDLENBQXZEO0FBQ0gsaUJBSkQsTUFJTyxJQUFJLEtBQUssSUFBTCxLQUFjLFNBQWxCLEVBQTZCO0FBQ2hDLHlCQUFLLEtBQUwsQ0FBVyxXQUFYLEdBQXlCLEtBQUssSUFBOUI7QUFDQSx5QkFBSyxLQUFMLENBQVcsV0FBWCxHQUF5QixLQUFLLElBQTlCO0FBQ0EseUJBQUssS0FBTCxDQUFXLE9BQVgsR0FBcUIsQ0FBckI7QUFDSDtBQUNELG9CQUFJLEtBQUssSUFBTCxLQUFjLFNBQWQsSUFBMkIsT0FBTyxLQUFLLElBQVosSUFBb0IsU0FBbkQsRUFBOEQ7QUFDMUQseUJBQUssS0FBTCxDQUFXLFVBQVgsR0FBd0IsS0FBSyxJQUE3QjtBQUNILGlCQUZELE1BRU87QUFDSCx5QkFBSyxLQUFMLENBQVcsVUFBWCxHQUF3QixLQUF4QjtBQUNIO0FBQ0o7QUFDSjs7O2lDQUVROztBQUVMLGdCQUFJLEtBQUssS0FBTCxDQUFXLE1BQWYsRUFBdUI7QUFDbkIscUJBQUssS0FBTCxDQUFXLEtBQVgsR0FBbUIsS0FBbkI7QUFDSCxhQUZELE1BRU87QUFDSCxxQkFBSyxLQUFMLEdBQWEsS0FBYjtBQUNIO0FBQ0Qsb0JBQVEsR0FBUixDQUFZLEtBQUssS0FBakI7QUFFSDs7OytCQUVNOztBQUVILGdCQUFJLEtBQUssS0FBTCxDQUFXLE1BQWYsRUFBdUI7QUFDbkIscUJBQUssS0FBTCxDQUFXLEtBQVgsR0FBbUIsSUFBbkI7QUFDSCxhQUZELE1BRU87QUFDSCxxQkFBSyxLQUFMLEdBQWEsSUFBYjtBQUNIO0FBQ0Qsb0JBQVEsR0FBUixDQUFZLEtBQUssS0FBakI7QUFFSDs7O2dDQUVPO0FBQ0osaUJBQUssSUFBTDtBQUNBLGlCQUFLLEtBQUwsQ0FBVyxLQUFYO0FBQ0EsaUJBQUssaUJBQUwsR0FBeUIsS0FBSyxLQUFMLENBQVcsV0FBcEM7QUFDSDs7O21DQUVVO0FBQ1AsbUJBQU8sS0FBSyxLQUFMLENBQVcsTUFBbEI7QUFDSDs7O2lDQUVRO0FBQ0wsaUJBQUssTUFBTDtBQUNBLGdCQUFJLEtBQUssaUJBQVQsRUFDSSxLQUFLLEtBQUwsQ0FBVyxXQUFYLEdBQXlCLEtBQUssaUJBQTlCO0FBQ0osaUJBQUssS0FBTCxDQUFXLElBQVg7QUFDSDs7Ozs7O2tCQUtVLGUiLCJmaWxlIjoiZ2VuZXJhdGVkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbigpe2Z1bmN0aW9uIHIoZSxuLHQpe2Z1bmN0aW9uIG8oaSxmKXtpZighbltpXSl7aWYoIWVbaV0pe3ZhciBjPVwiZnVuY3Rpb25cIj09dHlwZW9mIHJlcXVpcmUmJnJlcXVpcmU7aWYoIWYmJmMpcmV0dXJuIGMoaSwhMCk7aWYodSlyZXR1cm4gdShpLCEwKTt2YXIgYT1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK2krXCInXCIpO3Rocm93IGEuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixhfXZhciBwPW5baV09e2V4cG9ydHM6e319O2VbaV1bMF0uY2FsbChwLmV4cG9ydHMsZnVuY3Rpb24ocil7dmFyIG49ZVtpXVsxXVtyXTtyZXR1cm4gbyhufHxyKX0scCxwLmV4cG9ydHMscixlLG4sdCl9cmV0dXJuIG5baV0uZXhwb3J0c31mb3IodmFyIHU9XCJmdW5jdGlvblwiPT10eXBlb2YgcmVxdWlyZSYmcmVxdWlyZSxpPTA7aTx0Lmxlbmd0aDtpKyspbyh0W2ldKTtyZXR1cm4gb31yZXR1cm4gcn0pKCkiLCJ2YXIgbGFuZ3VhZ2U7XG5cbmZ1bmN0aW9uIGdldEJyb3dzZXJMYW5ndWFnZSgpIHtcbiAgICB2YXIgbGFuZztcblxuICAgIGlmIChuYXZpZ2F0b3IudXNlckxhbmd1YWdlKSB7XG4gICAgICAgIGxhbmcgPSBuYXZpZ2F0b3IudXNlckxhbmd1YWdlO1xuICAgICAgICBcbiAgICAgICAgaWYgKGxhbmcuaW5kZXhPZignemgnKSA9PSAtMSlcbiAgICAgICAgXG4gICAgICAgICAgICBsYW5nID0gbGFuZy5zcGxpdChcIi1cIilbMF07XG4gICAgICAgIFxuICAgICAgICBlbHNlIGlmIChsYW5nICE9ICd6aCcpIHtcbiAgICAgICAgXG4gICAgICAgICAgICBsYW5nID0gJ3poLXRyYWRpdGlvbmFsJ1xuICAgICAgICB9XG4gICAgfSBlbHNlIGlmIChuYXZpZ2F0b3IubGFuZ3VhZ2UpIHtcbiAgICAgICAgXG4gICAgICAgIGxhbmcgPSBuYXZpZ2F0b3IubGFuZ3VhZ2U7XG4gICAgICAgIFxuXG4gICAgICAgIGlmIChsYW5nLmluZGV4T2YoJ3poJykgPT0gLTEpXG4gICAgICAgIFxuICAgICAgICAgICAgbGFuZyA9IGxhbmcuc3BsaXQoXCItXCIpWzBdO1xuICAgICAgICBcbiAgICAgICAgZWxzZSBpZiAobGFuZyAhPSAnemgnKSB7XG4gICAgICAgIFxuICAgICAgICAgICAgbGFuZyA9ICd6aC10cmFkaXRpb25hbCc7XG4gICAgICAgIFxuICAgICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgICAgXG4gICAgICAgIGxhbmcgPSBcImVuXCI7XG4gICAgfVxuXG4gICAgcmV0dXJuIGxhbmc7XG5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldExvY2FsaXNlZEN0YSgpIHtcbiAgICBpZiAobGFuZ3VhZ2UgPT0gbnVsbClcbiAgICAgICAgbGFuZ3VhZ2UgPSBnZXRCcm93c2VyTGFuZ3VhZ2UoKTtcbiAgICB2YXIgdGV4dCA9IFwiR0VUXCI7XG4gICAgdmFyIGZvbnQgPSAnbXlGb250JztcbiAgICB2YXIgZm9udFNpemVNdWx0aXBsaWVyID0gMC40O1xuICAgIHN3aXRjaCAobGFuZ3VhZ2UpIHtcbiAgICAgICAgY2FzZSAnYXInOlxuICAgICAgICAgICAgdGV4dCA9ICfYtNix2KfYoSc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAncHQnOlxuICAgICAgICAgICAgdGV4dCA9ICdPYnRlcic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnemgnOlxuICAgICAgICAgICAgdGV4dCA9ICfojrflj5YnO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2NzJzpcbiAgICAgICAgICAgIHRleHQgPSAnWsOtc2thdCc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZGEnOlxuICAgICAgICAgICAgdGV4dCA9ICdIZW50JztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdubCc6XG4gICAgICAgICAgICB0ZXh0ID0gJ0Rvd25sb2FkZW4nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2ZpJzpcbiAgICAgICAgICAgIHRleHQgPSAnTGF0YWEnO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ2ZyJzpcbiAgICAgICAgICAgIHRleHQgPSAnT2J0ZW5pcic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZGUnOlxuICAgICAgICAgICAgdGV4dCA9ICdXaWxsIGljaCBoYWJlbic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnaWQnOlxuICAgICAgICAgICAgdGV4dCA9ICdEYXBhdGthbic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnaXQnOlxuICAgICAgICAgICAgdGV4dCA9ICdTY2FyaWNhJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdtcyc6XG4gICAgICAgICAgICB0ZXh0ID0gJ0RhcGF0a2FuJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdwbCc6XG4gICAgICAgICAgICB0ZXh0ID0gJ1BvYmllcnonO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3J1JzpcbiAgICAgICAgICAgIHRleHQgPSAn0J/QvtC70YPRh9C40YLRjCc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZXMnOlxuICAgICAgICAgICAgdGV4dCA9ICdPYnRlbmVyJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd0aCc6XG4gICAgICAgICAgICB0ZXh0ID0gJ+C4o+C4seC4mic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAndHInOlxuICAgICAgICAgICAgdGV4dCA9ICdFZGluaW4nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3poLXRyYWRpdGlvbmFsJzpcbiAgICAgICAgICAgIHRleHQgPSAn5Y+W5b6XJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdqYSc6XG4gICAgICAgICAgICB0ZXh0ID0gJ+WFpeaJiyc7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAna28nOlxuICAgICAgICAgICAgdGV4dCA9ICfri6TsmrTroZzrk5ztlZjquLAnO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ25iJzpcbiAgICAgICAgICAgIHRleHQgPSAnU2thZmYgZGVnJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdwdCc6XG4gICAgICAgICAgICB0ZXh0ID0gJ09idGVyJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdlcyc6XG4gICAgICAgICAgICB0ZXh0ID0gJ0NvbXByYXInO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ3N2JzpcbiAgICAgICAgICAgIHRleHQgPSAnU2thZmZhJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd2aSc6XG4gICAgICAgICAgICB0ZXh0ID0gJ1ThuqNpJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGV4dCA9IFwiR0VUXCI7XG4gICAgfVxuICAgIHJldHVybiB7ICd0ZXh0JzogdGV4dC50b1VwcGVyQ2FzZSgpLCAnZm9udCc6IGZvbnQsICdmb250U2l6ZU11bHRpcGxpZXInOiBmb250U2l6ZU11bHRpcGxpZXIgfTtcbn0iLCJpbXBvcnQgVmlkZW9Db250cm9sbGVyIGZyb20gJy4vdmlkZW8tY29udHJvbGxlcic7XG5pbXBvcnQgKiBhcyBVdGlscyBmcm9tICcuL2F1dG8tbG9jYWxpc2F0aW9uLXV0aWwnO1xuXG52YXIgdmlkZW9QYXRoID0gJ3ZpZGVvLm1wNCc7XG5cbnZhciBzdGF0aWNJbWdTcmMgPSAnYmctc3RhdGljLmpwZyc7XG5cbnZhciBmcm9tID0gMDsgLy8gdmlkZW8gc3RhcnRpbmcgcG9pbnRcblxudmFyIHRvID0gbnVsbDsgLy8gdmlkZW8gZW5kcyBwb2ludCwgaWYgd2FudCBpdCB0byBsb29wLCBsZWF2ZSBpdCBhcyBudWxsXG5cbnZhciBwcmV2aWV3Q2Fyb3VzZWw7IC8vIGNhcm91c2VsIHNob290XG5cbnZhciB2aWRlb0NvbnRyb2xsZXIgPSBudWxsO1xuXG52YXIgbXV0ZWQgPSB0cnVlO1xuXG52YXIgaW5mb0NvbnRlbnRUb3AgPSAxMDAwMDtcbnZhciBpbmZvQ29udGVudEJvdHRvbSA9IDA7XG5cbnZhciBjb250ZW50Q2xvbmVmbGFnID0gZmFsc2U7XG5cbmZ1bmN0aW9uIG1haW4oKSB7XG5cblxuICAgIC8vLy8vLS0tLS0tIENUQSAtLS0tLS0tLS0vLy8vLy8vLy8vXG5cbiAgICB2YXIgdGV4dCA9IFV0aWxzLmdldExvY2FsaXNlZEN0YSgpLnRleHQ7XG4gICAgdmFyIGZvbnRGYW1pbHkgPSBVdGlscy5nZXRMb2NhbGlzZWRDdGEoKS5mb250O1xuICAgIHZhciBmb250U2l6ZU11bHRpcGxpZXIgPSBVdGlscy5nZXRMb2NhbGlzZWRDdGEoKS5mb250U2l6ZU11bHRpcGxpZXI7XG5cbiAgICB2YXIgZm9udFNpemUgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndnVuZ2xlLWN0YScpLm9mZnNldEhlaWdodCAqIGZvbnRTaXplTXVsdGlwbGllcjtcblxuXG5cbiAgICAvLyB2YXIgZm9udE1hcmdpblRvcCA9IG9yaWVudGF0aW9uQ2hlY2soKT09J3BvcnRyYWl0Jz8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2N0YS1pbWcnKS5vZmZzZXRIZWlnaHQgKiAwLjA1IDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2N0YS1pbWcnKS5vZmZzZXRIZWlnaHQgKiAwLjM7XG5cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndnVuZ2xlLWN0YScpLnN0eWxlLmZvbnRTaXplID0gZm9udFNpemUgKyAncHgnO1xuICAgIC8vIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjdGEtdGV4dCcpLnN0eWxlLnRvcCA9IGZvbnRNYXJnaW5Ub3AgKyAncHgnO1xuXG5cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndnVuZ2xlLWN0YScpLnN0eWxlLm9wYWNpdHkgPSAxO1xuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Z1bmdsZS1jdGEnKS5pbm5lckhUTUwgPSB0ZXh0O1xuXG4gICAgLy8gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2luZm8tY29udGVudC1maXhlZC1jdGEnKS5pbm5lckhUTUwgPSB0ZXh0O1xuXG4gICAgYmluZEN0YUNsaWNrKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2dW5nbGUtY3RhJykpO1xuXG4gICAgYmluZEN0YUNsaWNrKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdhcHAtaWNvbicpKTtcblxuXG4gICAgLy8vLy8tLS0tLS0gQ1RBIEVORCAtLS0tLS0vLy8vLy8vLy8vXG5cblxuXG5cbiAgICAvLy8vLS0tLS0tIFdJTkRPVyBTQ1JPTEwgLS0tLS0tLS0vLy8vLy8gXG5cbiAgICAvLyB2YXIgaW5mb0NvbnRlbnRUb3AgPSAkKCcjdmlkZW9CZycpLnBvc2l0aW9uKCkudG9wICsgJCgnI3ZpZGVvQmcnKS5oZWlnaHQoKTtcblxuXG5cbiAgICAkKCcjd3JhcCcpLnNjcm9sbChmdW5jdGlvbigpIHtcblxuICAgICAgICBzdGlja3lCYW5uZXIoKTtcbiAgICAgICAgc2hvd1Njcm9sbEluZGljYXRvcigkKHRoaXMpLnNjcm9sbFRvcCgpKTtcblxuICAgICAgICBpZiAoaW5mb0NvbnRlbnRUb3AgPD0gMCkge1xuICAgICAgICAgICAgaWYgKCQodGhpcykuc2Nyb2xsVG9wKCkgPj0gaW5mb0NvbnRlbnRUb3ApIHtcblxuICAgICAgICAgICAgICAgIHJlcG9zaXRpb25JbmZvQ29udGVudCgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgIH0gZWxzZSB7XG5cbiAgICAgICAgICAgICQoJyNpbmZvLWNsb25lJykuY3NzKCdvcGFjaXR5JywgMCk7XG4gICAgICAgICAgICAkKCcjaW5mby1jb250ZW50JykuY3NzKCdvcGFjaXR5JywgMSk7XG4gICAgICAgIH1cblxuICAgICAgICBpbmZvQ29udGVudFRvcCA9ICQoJyNpbmZvLWNvbnRlbnQnKS5vZmZzZXQoKS50b3A7XG5cblxuXG4gICAgfSk7XG5cblxuICAgIC8vLy8tLS0tLS0gV0lORE9XIFNDUk9MTCBFTkQgLS0tLS0tLS0vLy8vLy8gXG5cbn1cblxuZnVuY3Rpb24gcmVwb3NpdGlvbkluZm9Db250ZW50KCkge1xuXG4gICAgaWYgKCFjb250ZW50Q2xvbmVmbGFnKSB7XG5cbiAgICAgICAgJChcIiNpbmZvLWNvbnRlbnRcIikuY2xvbmUoKS5hcHBlbmRUbyhcIiN3cmFwXCIpLmFkZENsYXNzKCdmaXhlZCcpLmF0dHIoJ2lkJywgJ2luZm8tY2xvbmUnKTtcblxuICAgICAgICAkKCcjaW5mby1jbG9uZScpLmZpbmQoJyN2dW5nbGUtY3RhJykuYXR0cignaWQnLCAndnVuZ2xlLWN0YS1jbG9uZScpO1xuICAgICAgICAkKCcjaW5mby1jbG9uZScpLmZpbmQoJyNhcHAtaWNvbicpLmF0dHIoJ2lkJywgJ2FwcC1pY29uLWNsb25lJyk7XG5cbiAgICAgICAgYmluZEN0YUNsaWNrKGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2dW5nbGUtY3RhLWNsb25lJykpO1xuICAgICAgICBiaW5kQ3RhQ2xpY2soZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FwcC1pY29uLWNsb25lJykpO1xuXG4gICAgICAgICQoJyNpbmZvLWNvbnRlbnQnKS5jc3MoJ29wYWNpdHknLCAwKTtcblxuICAgICAgICBjb250ZW50Q2xvbmVmbGFnID0gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKCcjaW5mby1jbG9uZScpLmNzcygnb3BhY2l0eScsIDEpO1xuICAgICAgICAkKCcjaW5mby1jb250ZW50JykuY3NzKCdvcGFjaXR5JywgMCk7XG5cbiAgICB9XG59XG5cbmZ1bmN0aW9uIGJpbmRDdGFDbGljayhvYmopIHtcbiAgICAvLyBjb25zb2xlLmxvZyhvYmouZm9jdXMpO1xuICAgIC8vIG9iai5mb2N1cygpO1xuICAgIG9iai5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24oKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdjdGEgZG93bmxvYWQnKTtcbiAgICAgICAgcGFyZW50LnBvc3RNZXNzYWdlKCdkb3dubG9hZCcsICcqJyk7XG4gICAgfSk7XG5cbn1cblxuXG4vLyBmdW5jdGlvbiBpc0VsZW1lbnRJblZpZXdwb3J0KGVsKSB7XG5cbi8vICAgICB2YXIgcmVjdCA9IGVsLnBvc2l0aW9uKCk7XG5cbi8vICAgICByZXR1cm4gKFxuLy8gICAgICAgICByZWN0LnRvcCArIHBhcnNlSW50KGVsLmNzcygnbWFyZ2luLXRvcCcpKSA+PSAod2luZG93LmlubmVySGVpZ2h0IHx8IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQpKVxuXG4vLyB9XG5cbmZ1bmN0aW9uIHN0aWNreUJhbm5lcigpIHtcbiAgICBpZihkb2N1bWVudC5ib2R5LmNsaWVudFdpZHRoID4gZG9jdW1lbnQuYm9keS5jbGllbnRIZWlnaHQgJiYgZG9jdW1lbnQuYm9keS5jbGllbnRIZWlnaHQgPD0gNTAwKXtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICgkKCcjd3JhcCcpLnNjcm9sbFRvcCgpIDwgaW5mb0NvbnRlbnRCb3R0b20gLSBkb2N1bWVudC5ib2R5LmNsaWVudEhlaWdodCkge1xuICAgICAgICAkKCcjaW5mby1jb250ZW50JykuYWRkQ2xhc3MoJ2ZpeGVkVG9Cb3R0b20nKVxuICAgIH0gZWxzZSB7XG4gICAgICAgICQoJyNpbmZvLWNvbnRlbnQnKS5yZW1vdmVDbGFzcygnZml4ZWRUb0JvdHRvbScpO1xuICAgIH1cblxuXG59XG5cblxuXG5mdW5jdGlvbiBpbml0Q2Fyb3VzZWwoKSB7XG5cbiAgICB2YXIgZDtcblxuICAgIGZvciAodmFyIGkgPSAwOyBpIDwgd2luZG93c1NldHRpbmdzLmNhcm91c2VsSW1nLmxlbmd0aDsgaSsrKSB7XG5cbiAgICAgICAgZCA9ICQoJzxpbWc+Jyk7XG5cbiAgICAgICAgZC5hdHRyKFwiZGF0YS1mbGlja2l0eS1sYXp5bG9hZFwiLCB3aW5kb3dzU2V0dGluZ3MuY2Fyb3VzZWxJbWdbaV0pO1xuXG4gICAgICAgICQoJyNtYWluLWNhcm91c2VsJykuYXBwZW5kKGQpO1xuICAgIH1cblxuICAgIGlmIChwcmV2aWV3Q2Fyb3VzZWwgPT0gbnVsbCkge1xuXG4gICAgICAgIHByZXZpZXdDYXJvdXNlbCA9IG5ldyBGbGlja2l0eShkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbWFpbi1jYXJvdXNlbCcpLCB7XG4gICAgICAgICAgICAvLyBHYWxsZXJ5IE9wdGlvbnM6XG4gICAgICAgICAgICBjZWxsQWxpZ246ICdjZW50ZXInLFxuICAgICAgICAgICAgLy8gY29udGFpbjogdHJ1ZSxcbiAgICAgICAgICAgIHByZXZOZXh0QnV0dG9uczogdHJ1ZSwgLy8gRGlzcGxheSBhcnJvdyBjb250cm9scyBbVHJ1ZSBvciBmYWxzZV1cbiAgICAgICAgICAgIHNldEdhbGxlcnlTaXplOiBmYWxzZSwgLy8gRE8gTk9UIFRPVUNIISFcbiAgICAgICAgICAgIHBhZ2VEb3RzOiBmYWxzZSwgLy8gRE8gTk9UIFRPVUNIISFcbiAgICAgICAgICAgIHdyYXBBcm91bmQ6IHRydWUsIC8vIFRvZ2dsZSBlbmRsZXNzIHNjcm9sbGluZyBbVHJ1ZSBvciBmYWxzZV1cbiAgICAgICAgICAgIGZ1bGxzY3JlZW46IHRydWUsXG4gICAgICAgICAgICBsYXp5TG9hZDogMyxcbiAgICAgICAgICAgIGFjY2Vzc2liaWxpdHk6IHRydWUsXG4gICAgICAgICAgICAvLyBmcmVlU2Nyb2xsOiBmYWxzZSwgLy8gVG9nZ2xlIHN0aWNrZXluZXNzIHNjcm9sbGluZyBbVHJ1ZSBvciBmYWxzZV1cbiAgICAgICAgICAgIGF1dG9QbGF5OiAzMDAwLCAvLyBTZXQgdGhlIERlbGF5IGJldHdlZW4gc3dpdGNoaW5nIEl0ZW1zXG4gICAgICAgICAgICBpbml0aWFsSW5kZXg6IDAgLy8gV2hpY2ggSXRlbSBzaG91bGQgYmUgY2VudGVyZWQgZmlyc3Q/IFxuICAgICAgICB9KTtcbiAgICB9XG5cbiAgICBwcmV2aWV3Q2Fyb3VzZWwub24oJ3N0YXRpY0NsaWNrJywgZnVuY3Rpb24oZXZlbnQsIHBvaW50ZXIsIGNlbGxFbGVtZW50LCBjZWxsSW5kZXgpIHtcbiAgICAgICAgLy8gY29uc29sZS5sb2coY2VsbEluZGV4KTtcblxuICAgICAgICBwcmV2aWV3Q2Fyb3VzZWwudmlld0Z1bGxzY3JlZW4oKTtcbiAgICAgICAgcHJldmlld0Nhcm91c2VsLnNlbGVjdChjZWxsSW5kZXgpO1xuXG4gICAgfSk7XG5cbiAgICBwcmV2aWV3Q2Fyb3VzZWwub24oJ2Z1bGxzY3JlZW5DaGFuZ2UnLCBmdW5jdGlvbihpc0Z1bGxzY3JlZW4pIHtcbiAgICAgICAgaWYgKGlzRnVsbHNjcmVlbikge1xuICAgICAgICAgICAgLy8gY29uc29sZS5sb2coJ2hpZGUnKTtcbiAgICAgICAgICAgIHBhcmVudC5wb3N0TWVzc2FnZSgnaGlkZUNsb3NlQnV0dG9uJywgJyonKTtcblxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKCQod2luZG93KS5zY3JvbGxUb3AoKSA8IGluZm9Db250ZW50VG9wKSB7XG4gICAgICAgICAgICAgICAgJCgnI2luZm8tY2xvbmUnKS5jc3MoJ29wYWNpdHknLCAwKTtcbiAgICAgICAgICAgICAgICAkKCcjaW5mby1jb250ZW50JykuY3NzKCdvcGFjaXR5JywgMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyByZXBvc2l0aW9uSW5mb0NvbnRlbnQoKTtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCQod2luZG93KS5zY3JvbGxUb3AoKSk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygkKCcjaW5mby1jb250ZW50Jykub2Zmc2V0KCkudG9wKTtcbiAgICAgICAgICAgIHBhcmVudC5wb3N0TWVzc2FnZSgncmV2ZWFsQ2xvc2VCdXR0b24nLCAnKicpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG5cblxuZnVuY3Rpb24gaW5pdENvbnRlbnQoKSB7XG4gICAgaWYgKHdpbmRvd3NTZXR0aW5ncy5hcHBOYW1lID09IHVuZGVmaW5lZCB8fCB3aW5kb3dzU2V0dGluZ3MuYXBwTmFtZSA9PSAnJykge1xuICAgICAgICBjb25zb2xlLmxvZygnbm8gYXBwTmFtZScpXG4gICAgfSBlbHNlIHtcbiAgICAgICAgJCgnI2FwcC1uYW1lJykuaHRtbCh3aW5kb3dzU2V0dGluZ3MuYXBwTmFtZSk7XG4gICAgfVxuXG5cbiAgICBpZiAod2luZG93c1NldHRpbmdzLmNhbGxPdXQgPT0gdW5kZWZpbmVkIHx8IHdpbmRvd3NTZXR0aW5ncy5jYWxsT3V0ID09ICcnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdubyBjYWxsT3V0JylcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKCcjYXBwLWNhbGxvdXQnKS5odG1sKHdpbmRvd3NTZXR0aW5ncy5jYWxsT3V0KTtcbiAgICB9XG5cbiAgICBpZiAod2luZG93c1NldHRpbmdzLnN0YXJzID09IHVuZGVmaW5lZCB8fCB3aW5kb3dzU2V0dGluZ3Muc3RhcnMubGVuZ3RoIDwgNSkge1xuICAgICAgICBjb25zb2xlLmxvZygnZml2ZSBzdGFycyBoYXZlIHRvIGJlIGRlZmluZWQnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgZCA9ICQoXCI8ZGl2IC8+XCIpLmFwcGVuZFRvKCQoJyNhcHAtc3RhcnMnKSk7XG5cbiAgICAgICAgdmFyIHNwYW47XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgd2luZG93c1NldHRpbmdzLnN0YXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInZ1bmdsZS1zdGFyLVwiICsgd2luZG93c1NldHRpbmdzLnN0YXJzW2ldKTtcbiAgICAgICAgICAgIHNwYW4gPSAkKFwiPHNwYW4gLz5cIikuYWRkQ2xhc3MoXCJzdGFyXCIpLmFkZENsYXNzKFwidnVuZ2ljb24tc3Rhci1cIiArIHdpbmRvd3NTZXR0aW5ncy5zdGFyc1tpXSk7XG4gICAgICAgICAgICBzcGFuLmFwcGVuZFRvKGQpO1xuICAgICAgICB9XG5cbiAgICB9XG5cbiAgICBpZiAod2luZG93c1NldHRpbmdzLnJldmlld0NvdW50cyA9PSB1bmRlZmluZWQgfHwgd2luZG93c1NldHRpbmdzLnJldmlld0NvdW50cyA9PSAnJykge1xuICAgICAgICBjb25zb2xlLmxvZygnbm8gcmV2aWV3Q291bnRzJylcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKFwiPHNwYW4gLz5cIikuYWRkQ2xhc3MoXCJjb3VudHNcIikuaHRtbCh3aW5kb3dzU2V0dGluZ3MucmV2aWV3Q291bnRzKS5hcHBlbmRUbygkKFwiI2FwcC1zdGFyc1wiKSk7XG5cblxuICAgIH1cblxuXG5cbiAgICBpZiAod2luZG93c1NldHRpbmdzLmRlc2NyaXB0aW9uQ29udGVudCA9PSB1bmRlZmluZWQgfHwgd2luZG93c1NldHRpbmdzLmRlc2NyaXB0aW9uQ29udGVudCA9PSAnJykge1xuICAgICAgICBjb25zb2xlLmxvZygnbm8gZGVzY3JpcHRpb25Db250ZW50JylcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKCcjaW5mby1hcHAtZGVzY3JpcHRpb24tY29udGVudCcpLmh0bWwod2luZG93c1NldHRpbmdzLmRlc2NyaXB0aW9uQ29udGVudCk7XG4gICAgfVxuXG5cbiAgICBpZiAod2luZG93c1NldHRpbmdzLkVTUkIgPT0gdW5kZWZpbmVkIHx8IHdpbmRvd3NTZXR0aW5ncy5FU1JCID09IHt9KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdubyBFU1JCJylcbiAgICB9IGVsc2Uge1xuICAgICAgICBpZiAod2luZG93c1NldHRpbmdzLkVTUkIuaW1hZ2UgJiYgd2luZG93c1NldHRpbmdzLkVTUkIuaW1hZ2UgPT0gJycpIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdubyBFU1JCIGltYWdlJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAkKCc8aW1nIC8+JykuYXR0cignc3JjJywgd2luZG93c1NldHRpbmdzLkVTUkIuaW1hZ2UpLmFwcGVuZFRvKCQoJyNFU1JCJykpO1xuICAgICAgICB9XG5cblxuICAgICAgICBpZiAod2luZG93c1NldHRpbmdzLkVTUkIudGV4dCAmJiB3aW5kb3dzU2V0dGluZ3MuRVNSQi50ZXh0ID09ICcnKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnbm8gRVNSQiB0ZXh0Jyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAkKCc8cCAvPicpLmh0bWwod2luZG93c1NldHRpbmdzLkVTUkIudGV4dCkuYXBwZW5kVG8oJCgnI0VTUkInKSk7XG4gICAgICAgIH1cblxuXG4gICAgfVxuXG4gICAgLy8gJCgnI2luZm8tY29udGVudC1maXhlZCcpXG4gICAgLy8gICAgIC5hcHBlbmQoXCI8aW1nIHNyYz0nYXBwLWljb24uanBnJz5cIilcbiAgICAvLyAgICAgLmFwcGVuZChcIjxwPlwiICsgd2luZG93c1NldHRpbmdzLmFwcE5hbWUgKyBcIjwvcD5cIilcbiAgICAvLyAgICAgLy8gLmFwcGVuZChcIjxkaXY+XCIrd2luZG93c1NldHRpbmdzLmFwcE5hbWUrXCI8L2Rpdj5cIilcbiAgICAvLyAgICAgLmFwcGVuZChcIjxidXR0b24gaWQ9J2luZm8tY29udGVudC1maXhlZC1jdGEnPkdldDwvYnV0dG9uPlwiKTtcblxufVxuXG5cbmZ1bmN0aW9uIHNob3dTY3JvbGxJbmRpY2F0b3IoY3VycmVudFNjcm9sbCkge1xuXG4gICAgaWYgKGN1cnJlbnRTY3JvbGwgPiAxMCkge1xuICAgICAgICAkKCcjc2Nyb2xsSW5kaWNhdG9yJykuYWRkQ2xhc3MoJ2hpZGUnKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICAkKCcjc2Nyb2xsSW5kaWNhdG9yJykucmVtb3ZlQ2xhc3MoJ2hpZGUnKTtcbiAgICAgICAgJCgnI3Njcm9sbEluZGljYXRvcicpLmZpbmQoJy5kb3QnKS5lYWNoKGZ1bmN0aW9uKGluZGV4KSB7XG4gICAgICAgICAgICAkKHRoaXMpLmFkZENsYXNzKCdmYWRlSW5Eb3duLScgKyBpbmRleCk7XG4gICAgICAgIH0pXG4gICAgfVxufVxuXG53aW5kb3cucmVzaXplID0gZnVuY3Rpb24oKSB7XG4gICAgcHJldmlld0Nhcm91c2VsLnJlc2l6ZSgpO1xuICAgIHN0aWNreUJhbm5lcigpO1xuICAgIFxufVxuXG53aW5kb3cub25sb2FkID0gZnVuY3Rpb24oKSB7XG5cblxuICAgIC8vc2hvdyB0aGUgdmlkZW8gb3Igc3RhdGljIGltYWdlXG4gICAgaWYgKHR5cGVvZiB2aWRlb1BhdGggIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICQoJyN2aWRlb0JnJykucmVtb3ZlQ2xhc3MoJ2hpZGUnKTtcblxuICAgICAgICAkKCcjYmctc3RhdGljLWltZycpLmFkZENsYXNzKCdoaWRlJyk7XG5cbiAgICAgICAgdmlkZW9Db250cm9sbGVyID0gbmV3IFZpZGVvQ29udHJvbGxlcigndmlkZW9CZycpO1xuXG4gICAgICAgIHZpZGVvQ29udHJvbGxlci5wbGF5KHZpZGVvUGF0aCwgeyBcImZyb21cIjogZnJvbSwgXCJsb29wXCI6IHRydWUsIFwic2ltcGxlXCI6IHRydWUgfSk7XG5cblxuICAgICAgICB2aWRlb0NvbnRyb2xsZXIudmlkZW8ub25sb2FkZWRtZXRhZGF0YSA9IGZ1bmN0aW9uKCkge1xuXG4gICAgICAgICAgICAvL2luaXQgRXZlcnl0aGluZyBcbiAgICAgICAgICAgICQoJ2JvZHknKS5yZW1vdmVDbGFzcygncHJlbG9hZCcpO1xuXG5cbiAgICAgICAgICAgIGluZm9Db250ZW50Qm90dG9tID0gJCgnI2luZm8tY29udGVudCcpLnBvc2l0aW9uKCkudG9wICsgJCgnI2luZm8tY29udGVudCcpLmhlaWdodCgpICsgcGFyc2VJbnQoJCgnI2luZm8tY29udGVudCcpLmNzcygnbWFyZ2luLXRvcCcpKTtcbiAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKCdpbmZvQ29udGVudEJvdHRvbScsIGluZm9Db250ZW50Qm90dG9tKTtcbiAgICAgICAgICAgIHN0aWNreUJhbm5lcigpO1xuXG5cblxuICAgICAgICAgICAgaWYgKCQoJy52dW5nbGUtZm9vdGVyJykub2Zmc2V0KCkudG9wID4gJCh3aW5kb3cpLmhlaWdodCgpKSB7XG5cblxuICAgICAgICAgICAgICAgIHNob3dTY3JvbGxJbmRpY2F0b3IoMCk7XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICQoJyNzY3JvbGxJbmRpY2F0b3InKS5jbGljayhmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAvLyBpZiAoaXNFbGVtZW50SW5WaWV3cG9ydCgkKFwiI2luZm8tY29udGVudFwiKSkpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gJCgnI2luZm8tY29udGVudCcpLmFuaW1hdGUoe1xuICAgICAgICAgICAgICAgICAgICAvLyAgICAgc2Nyb2xsVG9wOiAwXG4gICAgICAgICAgICAgICAgICAgIC8vIH0sIDEwMDApO1xuXG4gICAgICAgICAgICAgICAgICAgICQoJyN3cmFwJykuYW5pbWF0ZSh7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY3JvbGxUb3A6ICQoXCIjaW5mby1jb250ZW50XCIpLm9mZnNldCgpLnRvcFxuICAgICAgICAgICAgICAgICAgICB9LCA4MDApO1xuICAgICAgICAgICAgICAgIC8vIH1cbiAgICAgICAgICAgIH0pXG5cbiAgICAgICAgICAgIGluaXRDb250ZW50KClcbiAgICAgICAgICAgIGluaXRDYXJvdXNlbCgpO1xuICAgICAgICAgICAgbWFpbigpO1xuICAgICAgICB9O1xuICAgICAgICAvLyB1cGRhdGVWaWRlbygpO1xuXG5cbiAgICAgICAgLy8vLy0tLS0tLSBNVVRFIC0tLS0tLS0tLy8vLy8vIFxuXG4gICAgICAgICQoJyNtdXRlLXRvZ2dsZScpLnJlbW92ZUNsYXNzKCdoaWRlJyk7XG5cbiAgICAgICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ211dGUtdG9nZ2xlJykuYWRkRXZlbnRMaXN0ZW5lcigncG9pbnRlcmRvd24nLCBmdW5jdGlvbihldmVudCkge1xuXG4gICAgICAgICAgICBtdXRlZCA9ICFtdXRlZDtcblxuICAgICAgICAgICAgaWYgKG11dGVkKSB7XG4gICAgICAgICAgICAgICAgdmlkZW9Db250cm9sbGVyLm11dGUoKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdmlkZW9Db250cm9sbGVyLnVubXV0ZSgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAkKCcjaWNvbk11dGVkJykudG9nZ2xlKG11dGVkKTtcbiAgICAgICAgICAgICQoJyNpY29uVW5tdXRlZCcpLnRvZ2dsZSghbXV0ZWQpO1xuICAgICAgICB9KTtcbiAgICAgICAgLy8vLy8tLS0tLS0gTVVURSBUT0dHTEUgRU5EIC0tLS0tLS0tLy8vLy8vLy8vL1xuXG4gICAgfSBlbHNlIHtcblxuICAgICAgICAkKCcjdmlkZW9CZycpLmFkZENsYXNzKCdoaWRlJyk7XG5cbiAgICAgICAgJCgnI2JnLXN0YXRpYy1pbWcnKS5yZW1vdmVDbGFzcygnaGlkZScpO1xuXG4gICAgICAgICQoJyNiZy1zdGF0aWMtaW1nJykuYXR0cignc3JjJywgc3RhdGljSW1nU3JjKTtcbiAgICB9XG5cblxuICAgIC8vc2hvdyB0aGUgdmlkZW8gb3Igc3RhdGljIGltYWdlIEVORFxuXG5cblxufSIsIi8qXG49PT1WaWRlbyBDb250cm9sbGVyPT09XG5IYW5kbGVzIHZpZGVvIGNvbnRyb2xzLCBpbmNsdWRpbmcgcGxheWluZyBhIHZpZGVvLCBwYXVzaW5nIGEgdmlkZW8sIGNoYW5naW5nIHRoZSB2aWRlbyBzb3VyY2UsIGV0Yy5cbi0tIERvZXNuJ3QgdW5kZXJzdGFuZCBhbnl0aGluZyBhYm91dCB0aGUgbG9naWMgYmVoaW5kIHRyYW5zaXRpb25pbmcgYmV0d2VlbiB2aWRlb3Mgb3IgaW50ZXJhY3RpdmUgYXJlYXMuIC0tXG4qL1xuY2xhc3MgVmlkZW9Db250cm9sbGVyIHtcblxuICAgIGNvbnN0cnVjdG9yKGNvbnRhaW5lcikge1xuXG4gICAgICAgIHRoaXMuY29udGFpbmVyID0gY29udGFpbmVyO1xuICAgICAgICB0aGlzLnZpZGVvID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoY29udGFpbmVyKTtcblxuICAgICAgICB2YXIgc291cmNlRWxlbWVudHMgPSBkb2N1bWVudC5nZXRFbGVtZW50c0J5VGFnTmFtZShcInNvdXJjZVwiKTtcbiAgICAgICAgaWYgKHNvdXJjZUVsZW1lbnRzLmxlbmd0aCA9PSAwKVxuICAgICAgICAgICAgdGhpcy5zb3VyY2UgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzb3VyY2UnKTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgdGhpcy5zb3VyY2UgPSBzb3VyY2VFbGVtZW50c1swXTtcblxuICAgICAgICB0aGlzLnZpZGVvLmFwcGVuZENoaWxkKHRoaXMuc291cmNlKTtcbiAgICAgICAgdGhpcy52aWRlby5jb250cm9scyA9IGZhbHNlO1xuXG4gICAgICAgIHRoaXMubXV0ZWQgPSB0cnVlO1xuXG4gICAgICAgIC8vIHRoaXMuaW5pdFNpZ25hbHMoKTtcblxuICAgIH1cblxuICAgIGluaXRTaWduYWxzKCkge1xuICAgICAgICB0aGlzLm9uQ29tcGxldGUgPSBuZXcgUGhhc2VyLlNpZ25hbCgpO1xuICAgICAgICB0aGlzLm9uTG9vcCA9IG5ldyBQaGFzZXIuU2lnbmFsKCk7XG4gICAgICAgIC8vIHRoaXMudmlkZW8ub253YWl0aW5nID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcIlZJREVPIFdBSVRJTkdcIik7XG4gICAgICAgIC8vIH07XG4gICAgICAgIC8vIHRoaXMudmlkZW8ub25wbGF5aW5nID0gZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhcIlZJREVPIFBMQVlJTkdcIik7XG4gICAgICAgIC8vIH07XG4gICAgfVxuXG4gICAgLypcbiAgICA9PVBsYXk9PVxuICAgIFBsYXlzIHNwZWNpZmljIHZpZGVvLlxuICAgIFBhcmFtczpcbiAgICAgKyB2aWRlbyBzcmNcbiAgICAgKyBhcmdzOiBvYmplY3Qgd2l0aCBvcHRpb25hbCBhcmd1bWVudHMgdG8gY29uZmlndXJlIGhvdyB0byBwbGF5IHRoZSB2aWRlbyAob3B0aW9uYWwpXG4gICAgICAgICsgXCJsb29wXCIgOiBib29sICB2aWRlbyBsb29wcyBpZiB0cnVlXG4gICAgICAgICsgXCJmcm9tXCIgOiAxICAgICB3aGVyZSBkb2VzIHRoZSB2aWRlbyBzdGFydCBwbGF5aW5nIGZyb21cbiAgICAgICAgKyBcInRvXCIgOiAyICAgICAgIHdoZXJlIGRvZXMgdGhlIHZpZGVvIHBhdXNlXG4gICAgKi9cbiAgICBwbGF5KHNyYywgYXJncykge1xuICAgICAgICBpZiAodGhpcy52aWRlb05hbWUgPT0gdW5kZWZpbmVkIHx8IHRoaXMudmlkZW9OYW1lICE9IHNyYykge1xuXG4gICAgICAgICAgICB0aGlzLnZpZGVvTmFtZSA9IHNyYztcblxuICAgICAgICAgICAgdGhpcy5zb3VyY2Uuc2V0QXR0cmlidXRlKCdzcmMnLCBzcmMpO1xuXG4gICAgICAgICAgICB0aGlzLnZpZGVvLmxvYWQoKTtcblxuICAgICAgICAgICAgXG5cbiAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgICAgICAgIHRoaXMuaXNSZWFkeShmdW5jdGlvbigpIHtcblxuICAgICAgICAgICAgICAgIF90aGlzLnZpZGVvLm11dGVkID0gX3RoaXMubXV0ZWQ7XG4gICAgICAgICAgICAgICAgX3RoaXMudmlkZW8uY3VycmVudFRpbWUgPSAwO1xuICAgICAgICAgICAgICAgIF90aGlzLnZpZGVvLmVuZFRpbWUgPSAwO1xuICAgICAgICAgICAgICAgIF90aGlzLnZpZGVvLnBsYXkoKTtcbiAgICAgICAgICAgICAgICBpZiAoYXJncy5zaW1wbGUgPT0gdW5kZWZpbmVkIHx8ICFhcmdzLnNpbXBsZSlcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMuaW5pdFZpZGVvQXJncyhhcmdzKTtcbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMudmlkZW8uc2ltcGxlID0gYXJncy5zaW1wbGU7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhcmdzLmxvb3AgIT0gdW5kZWZpbmVkICYmIGFyZ3MubG9vcCkge1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy52aWRlby5sb29wID0gdHJ1ZTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coX3RoaXMudmlkZW8pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuaW5pdFZpZGVvQXJncyhhcmdzKTtcbiAgICAgICAgICAgIHRoaXMudmlkZW8ucGxheSgpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgLypcbiAgICA9PVVwZGF0ZSBsb29wPT1cbiAgICBTaG91bGQgYmUgY2FsbGVkIGZyb20gdGhlIGVuZGNhcmQgc3RhdGUuXG4gICAgKi9cbiAgICB1cGRhdGUoKSB7XG4gICAgICAgIC8vIGNvbnNvbGUubG9nKFwiVmlkZW8gQ29udHJvbGxlciB1cGRhdGVcIik7XG4gICAgICAgIHRoaXMudmlkZW8ubXV0ZWQgPSB0aGlzLm11dGVkO1xuICAgICAgICBpZiAodGhpcy52aWRlb0VuZGVkKCkpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnZpZGVvLnNob3VsZExvb3ApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvLmN1cnJlbnRUaW1lID0gdGhpcy52aWRlby5pbml0aWFsVGltZTtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvLnBsYXkoKTtcblxuICAgICAgICAgICAgICAgIGlmICh0aGlzLm9uTG9vcCAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uTG9vcC5kaXNwYXRjaCgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoIXRoaXMudmlkZW8ucGF1c2VkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMudmlkZW8ucGF1c2UoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHRoaXMub25Db21wbGV0ZSAhPSBudWxsKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLm9uQ29tcGxldGUuZGlzcGF0Y2goKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIXRoaXMudmlkZW8ucGF1c2VkICYmIHRoaXMudmlkZW9FbmRlZCgpKSB7XG4gICAgICAgICAgICB0aGlzLnZpZGVvLnBhdXNlKCk7XG4gICAgICAgICAgICBpZiAodGhpcy5vbkNvbXBsZXRlICE9IG51bGwpXG4gICAgICAgICAgICAgICAgdGhpcy5vbkNvbXBsZXRlLmRpc3BhdGNoKCk7XG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpc1JlYWR5KGNiKSB7XG5cbiAgICAgICAgdGhpcy5jYW5wbGF5dGhyb3VnaCA9IGZ1bmN0aW9uKCkge1xuXG4gICAgICAgICAgICAvLyByZWFkeVN0YXRlIDQgaW5kaWNhdGVzIHZpZGVvIGlzIHJlYWR5XG4gICAgICAgICAgICBpZiAodGhpcy5yZWFkeVN0YXRlIDw9IDMpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIHVuYmluZCBjYW5wbGF5dGhyb3VnaCBldmVudFxuICAgICAgICAgICAgdGhpcy5vbmNhbnBsYXl0aHJvdWdoID0gbnVsbDtcbiAgICAgICAgICAgIHJldHVybiBjYigpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMudmlkZW8ub25jYW5wbGF5dGhyb3VnaCA9IHRoaXMuY2FucGxheXRocm91Z2g7XG5cbiAgICAgICAgLy8gSWYgdGhlIHZpZGVvIGlzIGluIHRoZSBjYWNoZSBvZiB0aGUgYnJvd3NlcixcbiAgICAgICAgLy8gdGhlICdjYW5wbGF5dGhyb3VnaCcgZXZlbnQgbWlnaHQgaGF2ZSBiZWVuIHRyaWdnZXJlZFxuICAgICAgICAvLyBiZWZvcmUgd2UgcmVnaXN0ZXJlZCB0aGUgZXZlbnQgaGFuZGxlci5cbiAgICAgICAgaWYgKHRoaXMudmlkZW8ucmVhZHlTdGF0ZSA+IDMpIHtcblxuICAgICAgICAgICAgLy8gdW5iaW5kIGNhbnBsYXl0aHJvdWdoIGV2ZW50XG4gICAgICAgICAgICB0aGlzLm9uY2FucGxheXRocm91Z2ggPSBudWxsO1xuXG4gICAgICAgICAgICByZXR1cm4gY2IoKTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIC8qXG4gICAgUmV0dXJucyBpZiB2aWRlbyBoYXMgZW5kZWQuXG4gICAgVGhpcyBpbmNsdWRlcyBmdWxsLWxlbmd0aCBvZiB2aWRlbyAoaWYgbm8gZnJvbS90byBhcmdzIGhhdmUgYmVlbiBkZWZpbmVkKSwgb3Igc3BlY2lmaWVkIGZyYWdtZW50IChmcm9tL3RvKS5cbiAgICAqL1xuICAgIHZpZGVvRW5kZWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnZpZGVvLmVuZGVkIHx8IHRoaXMudmlkZW8uZW5kVGltZSAhPSAwICYmIHRoaXMudmlkZW8uY3VycmVudFRpbWUgPj0gdGhpcy52aWRlby5lbmRUaW1lO1xuICAgIH1cblxuICAgIC8qXG4gICAgUHJvY2Vzc2VzIGFuZCBsb2FkcyB2aWRlbyBhcmdzIGludG8gY2xhc3Mgc2V0dGluZ3NcbiAgICAqL1xuICAgIGluaXRWaWRlb0FyZ3MoYXJncykge1xuICAgICAgICBpZiAoYXJncyAhPT0gdW5kZWZpbmVkKSB7XG5cbiAgICAgICAgICAgIGlmIChhcmdzLmZyb20gIT09IHVuZGVmaW5lZCAmJiBhcmdzLnRvICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvLmluaXRpYWxUaW1lID0gYXJncy5mcm9tO1xuICAgICAgICAgICAgICAgIHRoaXMudmlkZW8uY3VycmVudFRpbWUgPSBhcmdzLmZyb207XG4gICAgICAgICAgICAgICAgdGhpcy52aWRlby5lbmRUaW1lID0gYXJncy50byAhPT0gdW5kZWZpbmVkID8gYXJncy50byA6IDA7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGFyZ3MuZnJvbSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy52aWRlby5pbml0aWFsVGltZSA9IGFyZ3MuZnJvbTtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvLmN1cnJlbnRUaW1lID0gYXJncy5mcm9tO1xuICAgICAgICAgICAgICAgIHRoaXMudmlkZW8uZW5kVGltZSA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYXJncy5sb29wICE9PSB1bmRlZmluZWQgJiYgdHlwZW9mIGFyZ3MubG9vcCA9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnZpZGVvLnNob3VsZExvb3AgPSBhcmdzLmxvb3A7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMudmlkZW8uc2hvdWxkTG9vcCA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgdW5tdXRlKCkge1xuXG4gICAgICAgIGlmICh0aGlzLnZpZGVvLnNpbXBsZSkge1xuICAgICAgICAgICAgdGhpcy52aWRlby5tdXRlZCA9IGZhbHNlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5tdXRlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nKHRoaXMudmlkZW8pO1xuXG4gICAgfVxuXG4gICAgbXV0ZSgpIHtcblxuICAgICAgICBpZiAodGhpcy52aWRlby5zaW1wbGUpIHtcbiAgICAgICAgICAgIHRoaXMudmlkZW8ubXV0ZWQgPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5tdXRlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2codGhpcy52aWRlbyk7XG5cbiAgICB9XG5cbiAgICBwYXVzZSgpIHtcbiAgICAgICAgdGhpcy5tdXRlKCk7XG4gICAgICAgIHRoaXMudmlkZW8ucGF1c2UoKTtcbiAgICAgICAgdGhpcy5wYXVzZWRDdXJyZW50VGltZSA9IHRoaXMudmlkZW8uY3VycmVudFRpbWU7XG4gICAgfVxuXG4gICAgaXNQYXVzZWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnZpZGVvLnBhdXNlZDtcbiAgICB9XG5cbiAgICByZXN1bWUoKSB7XG4gICAgICAgIHRoaXMudW5tdXRlKCk7XG4gICAgICAgIGlmICh0aGlzLnBhdXNlZEN1cnJlbnRUaW1lKVxuICAgICAgICAgICAgdGhpcy52aWRlby5jdXJyZW50VGltZSA9IHRoaXMucGF1c2VkQ3VycmVudFRpbWU7XG4gICAgICAgIHRoaXMudmlkZW8ucGxheSgpO1xuICAgIH1cblxuXG59XG5cbmV4cG9ydCBkZWZhdWx0IFZpZGVvQ29udHJvbGxlcjsiXX0=
