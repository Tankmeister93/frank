var windowsSettings = windowsSettings || {};


windowsSettings.appName = 'Club Vegas - New Slots 2020';

windowsSettings.stars = ['full', 'full', 'full', 'full', 'half']; // has to be five;

windowsSettings.reviewCounts = "432";

windowsSettings.callOut = 'Best NEW games 2020: Tired of playing the same online slots machines all the time? Experience a new Vegas slots app with endless free slots with bonuses!';

windowsSettings.descriptionContent = 'Play Club Vegas Slots - The hot, new casino slot heaven for Vegas quality slot lovers. Get your spin on and play them for FREE.\n\nThe HOTTEST online Casino 2020 - Experience a new Vegas slots app with endless free slots with bonuses, casino rewards programs, huge free slots jackpots and the best slot machines games inspired by Vegas casinos.\n\nClaim your 1,000,000 CASINO COINS WELCOME BONUS enter the Vegas world and start spinning the reels of all the most amazing free slots machines in one of the best online casino slots apps with daily bonuses.\n\nBest NEW games 2020: Tired of playing the same online slots machines all the time? Club Vegas Slots app releases new free slots with bonuses every week! With new slots machines added weekly, the wins never stop!';

windowsSettings.carouselImg = [
	"1.jpeg",
	"2.jpeg",
	"3.jpeg",
	"4.jpeg",
	"5.jpeg",

	// "1.png",
	// "2.png",
	// "3.png",
	// "4.png",
	// "5.png",

]

windowsSettings.ESRB = {
    image: 'ESRB.png',
    text: 'EVERYONE'
}

windowsSettings.defaultLang = "en";
windowsSettings.translations = {
    'Download': {
        en: "Download",
        de: "Download",
        fr: "T�l�charger",
        it: "Scarica",
        es: "Descargar",
        pt: "Baixar",
        ca: "Descarregar",
        tr: "Indir",
        nl: "Download",
        sv: "Ladda ner",
        id: "Download",
        no: "Nedlasting",
        nb: "Nedlasting",
        nn: "Nedlasting",
        pl: "Pobierz",
        da: "Hent",
        hr: "zbirka",
        sq: "Shkarko",
        sl: "prenesi",
        zu: "ukulanda",
        ga: "�osl�d�il",
        is: "s�kja",
        hu: "Let�lt�s",
        et: "lae alla",
        eu: "deskargatu",
        fi: "ladata",
        sw: "kupakua",
    },
    'Play!': {
        en: "Play!",
        de: "abspielen!",
        fr: "jouer!",
        it: "giocare!",
        es: "�Jugar!",
        pt: "Toque!",
        ca: "Jugar!",
        tr: "oyun!",
        nl: "spelen!",
        sv: "spela!",
        id: "bermain!",
        ro: "Joaca!",
        no: "spille!",
        nb: "spille!",
        nn: "spille!",
        ms: "Bermain!",
        da: "Spille!",
        hr: "Igra!",
        sq: "Luaj!",
        sl: "Igraj!",
        az: "Oynamaq!",
        zu: "Dlala!",
        ga: "Seinn!",
        is: "Leika!",
        hu: "J�t�k!",
        mt: "Play!",
        et: "M�ngi!",
        eu: "Jokatu!",
        fi: "Pelata!",
        sw: "Jaribu!",
    },
    'Play': {
        en: "Play",
        de: "abspielen",
        fr: "jouer",
        it: "giocare",
        es: "�Jugar",
        pt: "Toque",
        ca: "Jugar",
        tr: "oyun",
        nl: "spelen",
        sv: "spela",
        id: "bermain",
        ro: "Joaca",
        no: "spille",
        nb: "spille",
        nn: "spille",
        ms: "Bermain",
        da: "Spille",
        hr: "Igra",
        sq: "Luaj",
        sl: "Igraj",
        az: "Oynamaq",
        zu: "Dlala",
        ga: "Seinn",
        is: "Leika",
        hu: "J�t�k",
        mt: "Play",
        et: "M�ngi",
        eu: "Jokatu",
        fi: "Pelata",
        sw: "Jaribu",
    },

    'download_icon.png': {
    //   en: '',
    //   ja: 'ja-',
    //   zh: 'zh-',
    },
};
